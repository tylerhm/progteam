/*
3
1 2 3
4 5 6
7 8 0
1 2 3
7 0 4
8 6 5
4 2 6
3 1 5
7 0 8
 */

import java.util.*;

public class ac8694_prob8 {

	public static void main(String[] args) {
		new ac8694_prob8();
	}
	
	public int SIZE = 3;
	
	public ac8694_prob8() {
		Scanner sc = new Scanner(System.in);
		
		int[][] end = new int[SIZE][SIZE];
		
		int idx = 1;
		for(int i = 0; i < SIZE; i++){
			for(int j = 0; j < SIZE; j++){
				end[i][j] = idx;
				idx++;
			}
		}
		
		LinkedList<State> q = new LinkedList<State>();
		q.add(new State(end, 0));
		
		HashMap<String, Long> map = new HashMap<String, Long>();
		while(!q.isEmpty()){
			State u = q.poll();
			
			if(map.containsKey(u.hashcode())){
				if(map.get(u.hashcode()) <= u.steps){
					continue;
				}
			}
			map.put(u.hashcode(), u.steps);
						
			State a = swap(u, 1, 0);
			State b = swap(u, 0, 1);
			State c = swap(u, -1, 0);
			State d = swap(u, 0, -1);
			
			if(a != null){
				q.add(a);
			}
			if(b != null){
				q.add(b);
			}
			if(c != null){
				q.add(c);
			}
			if(d != null){
				q.add(d);
			}
		}
		
		int t = sc.nextInt();
		for(int tc = 0; tc < t; tc++){
			int[][] start = new int[SIZE][SIZE];
			
			for(int i = 0; i < SIZE; i++){
				for(int j = 0; j < SIZE; j++){
					start[i][j] = sc.nextInt();
					
					if(start[i][j] == 0){
						start[i][j] = 9;
					}
				}
			}
			
			State ans = new State(start, 0);
			System.out.println(map.get(ans.hashcode()));
		}
		
		sc.close();
	}
	
	public State swap(State a, int dy, int dx) {
		if(a.r + dy < 0 || a.r + dy >= SIZE || a.c + dx < 0 || a.c + dx >= SIZE){
			return null;
		}
		
		int[][] grid = new int[SIZE][SIZE];
		for(int i = 0; i < SIZE; i++){
			for(int j = 0; j < SIZE; j++){
				grid[i][j] = a.grid[i][j];
			}
		}
		
		int temp = grid[a.r + dy][a.c + dx];
		grid[a.r + dy][a.c + dx] = grid[a.r][a.c];
		grid[a.r][a.c] = temp;
		
		State answer = new State(grid, a.steps + 1, a.r + dy, a.c + dx);
		return answer;
	}
	
	public class State {
		int[][] grid;
		long steps;
		int r, c;
		
		public State(int[][] grid, long steps) {
			this.grid = grid;
			this.steps = steps;
			r = 2;
			c = 2;
		}
		
		public State(int[][] grid, long steps, int r, int c) {
			this.grid = grid;
			this.steps = steps;
			this.r = r;
			this.c = c;
		}
		
		public String hashcode() {
			StringBuilder code = new StringBuilder();
			
			for(int i = 0; i < SIZE; i++){
				code.append(Arrays.toString(grid[i]));
			}
			
			return code.toString();
		}
		
		public void output() {
			for(int i = 0; i < SIZE; i++){
				System.out.print(Arrays.toString(grid[i]) + " ");
			}
			System.out.println();
		}
	}
}

