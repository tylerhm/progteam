//Ryan Kelsey
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

public class ac8708_prob8 {
	public static void main(String[] args) {
		Map<State, Integer> map = new HashMap<State, Integer>();
		Queue<State> queue = new ArrayDeque<State>();
		queue.offer(new State(new int[][] {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}}, 0, 2, 2));
		map.put(queue.peek(), 0);
		
		while(!queue.isEmpty()) {
			State cur = queue.poll();
			
			int[][] arr = cur.arr;
			int zr = cur.zeroR, zc = cur.zeroC;
			
			if(zr > 0) {
				int[][] next = new int[3][3];
				for(int i = 0; i < 3; i++)
					for(int j = 0; j < 3; j++)
						next[i][j] = arr[i][j];
				next[zr][zc] = arr[zr - 1][zc];
				next[zr - 1][zc] = 0;
				State s = new State(next, cur.steps + 1, zr - 1, zc);
				if(!map.containsKey(s)) {
					map.put(s, cur.steps + 1);
					queue.offer(s);
				}
			}
			
			if(zr < 2) {
				int[][] next = new int[3][3];
				for(int i = 0; i < 3; i++)
					for(int j = 0; j < 3; j++)
						next[i][j] = arr[i][j];
				next[zr][zc] = arr[zr + 1][zc];
				next[zr + 1][zc] = 0;
				State s = new State(next, cur.steps + 1, zr + 1, zc);
				if(!map.containsKey(s)) {
					map.put(s, cur.steps + 1);
					queue.offer(s);
				}
			}
			
			if(zc > 0) {
				int[][] next = new int[3][3];
				for(int i = 0; i < 3; i++)
					for(int j = 0; j < 3; j++)
						next[i][j] = arr[i][j];
				next[zr][zc] = arr[zr][zc - 1];
				next[zr][zc - 1] = 0;
				State s = new State(next, cur.steps + 1, zr, zc - 1);
				if(!map.containsKey(s)) {
					map.put(s, cur.steps + 1);
					queue.offer(s);
				}
			}
			
			if(zc < 2) {
				int[][] next = new int[3][3];
				for(int i = 0; i < 3; i++)
					for(int j = 0; j < 3; j++)
						next[i][j] = arr[i][j];
				next[zr][zc] = arr[zr][zc + 1];
				next[zr][zc + 1] = 0;
				State s = new State(next, cur.steps + 1, zr, zc + 1);
				if(!map.containsKey(s)) {
					map.put(s, cur.steps + 1);
					queue.offer(s);
				}
			}
		}
		
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		
		for(int z = 1; z <= runs; z++) {
			int[][] arr = new int[3][3];
			for(int i = 0; i < 3; i++)
				for(int j = 0; j < 3; j++)
					arr[i][j] = scan.nextInt();
			System.out.println(map.get(new State(arr, 0, 0 ,0)));
		}
		scan.close();
	}
}

class State {
	public int[][] arr;
	public int steps;
	public int hashCode;
	public int zeroR, zeroC;
	
	public State(int[][] arr, int steps, int zeroR, int zeroC) {
		this.arr = arr;
		this.steps = steps;
		this.zeroR = zeroR;
		this.zeroC = zeroC;
		this.hashCode = Arrays.deepHashCode(arr);
	}
	
	public int hashCode() {
		return this.hashCode;
	}
	
	public boolean equals(Object obj) {
		return Arrays.deepEquals(this.arr, ((State)obj).arr);
	}
}
