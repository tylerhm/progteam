import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class ac8673_prob8 {
	public static int[] startState = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };

	public static void main(String[] Args) {
		Scanner sc = new Scanner(System.in);

		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		hm.put(Arrays.toString(startState), 0);
		Queue<int[]> vals = new LinkedList<int[]>();
		vals.add(startState);

		while (!vals.isEmpty()) {
			int[] nxt = vals.poll();
			int loc = 0;
			for (int k = 0; k < 9; k++) {
				if (nxt[k] == 0)
					loc = k;
			}
			if (loc % 3 != 0) {
				int[] nxtnxt = new int[9];
				for (int k = 0; k < 9; k++) {
					nxtnxt[k] = nxt[k];
				}
				nxtnxt[loc] = nxtnxt[loc - 1];
				nxtnxt[loc - 1] = 0;
				if (!hm.containsKey(Arrays.toString(nxtnxt))) {
					hm.put(Arrays.toString(nxtnxt),
							hm.get(Arrays.toString(nxt)) + 1);
					vals.add(nxtnxt);
				}
			}
			if (loc % 3 != 2) {
				int[] nxtnxt = new int[9];
				for (int k = 0; k < 9; k++) {
					nxtnxt[k] = nxt[k];
				}
				nxtnxt[loc] = nxtnxt[loc + 1];
				nxtnxt[loc + 1] = 0;
				if (!hm.containsKey(Arrays.toString(nxtnxt))) {
					hm.put(Arrays.toString(nxtnxt),
							hm.get(Arrays.toString(nxt)) + 1);
					vals.add(nxtnxt);
				}
			}
			if (loc / 3 != 2) {
				int[] nxtnxt = new int[9];
				for (int k = 0; k < 9; k++) {
					nxtnxt[k] = nxt[k];
				}
				nxtnxt[loc] = nxtnxt[loc + 3];
				nxtnxt[loc + 3] = 0;
				if (!hm.containsKey(Arrays.toString(nxtnxt))) {
					hm.put(Arrays.toString(nxtnxt),
							hm.get(Arrays.toString(nxt)) + 1);
					vals.add(nxtnxt);
				}
			}
			if (loc / 3 != 0) {
				int[] nxtnxt = new int[9];
				for (int k = 0; k < 9; k++) {
					nxtnxt[k] = nxt[k];
				}
				nxtnxt[loc] = nxtnxt[loc - 3];
				nxtnxt[loc - 3] = 0;
				if (!hm.containsKey(Arrays.toString(nxtnxt))) {
					hm.put(Arrays.toString(nxtnxt),
							hm.get(Arrays.toString(nxt)) + 1);
					vals.add(nxtnxt);
				}
			}
		}
		int n = sc.nextInt();
		while(n-->0){
			int[] nxt = new int[9];
			for (int k = 0; k < 9; k++){
				nxt[k] = sc.nextInt();
			}
			System.out.println(hm.get(Arrays.toString(nxt)));
		}
	}
}

