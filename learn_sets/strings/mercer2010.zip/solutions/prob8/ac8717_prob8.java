import java.util.*;
public class ac8717_prob8 {
	
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		HashMap<String, Integer> dp = new HashMap<String, Integer>();
		int cases = in.nextInt();
		String key;
		Solve(dp);
		for (int c = 0; c < cases; ++c) {
			key = "";
			for (int i = 0; i < 9; ++i) key += Integer.toString(in.nextInt());
			System.out.printf("%d%n", dp.get(key));
		}
		in.close();
	}
	
	public static void Solve(HashMap<String, Integer> dp) {
		Queue<String> q = new LinkedList<String>();
		int i, ind;
		String key;
		q.add("0123456780");
		do {
			key = q.remove();
			i = Integer.parseInt(key.substring(0, key.length() - 9));
			key = key.substring(key.length() - 9, key.length());
			dp.put(key, i);
			ind = key.indexOf('0');
			if (ind > 2 && !dp.containsKey(swap(key, ind, ind - 3))) q.add(Integer.toString(i + 1) + swap(key, ind, ind - 3));
			if (ind % 3 != 0 && !dp.containsKey(swap(key, ind, ind - 1))) q.add(Integer.toString(i + 1) + swap(key, ind, ind - 1));
			if ((ind + 1) % 3 != 0 && !dp.containsKey(swap(key, ind, ind + 1))) q.add(Integer.toString(i + 1) + swap(key, ind, ind + 1));
			if (ind < 6 && !dp.containsKey(swap(key, ind, ind + 3))) q.add(Integer.toString(i + 1) + swap(key, ind, ind + 3));
		} while (!q.isEmpty());
	}
	
	public static String swap(String str, int i, int j) {
		String s = "";
		for (int k = 0; k < str.length(); ++k) {
			if (k == i) s += str.charAt(j);
			else if (k == j) s += str.charAt(i);
			else s += str.charAt(k);
		}
		return s;
	}
}

