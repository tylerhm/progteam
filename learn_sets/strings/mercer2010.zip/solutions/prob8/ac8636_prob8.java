import java.io.File;
import java.util.*;


public class ac8636_prob8 {
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		
		Queue<State> queue = new ArrayDeque<State>();
		Map<State, Integer> states = new HashMap<State, Integer>();
		
		queue.add(new State(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 0 }, 0, 8));
		
		while(!queue.isEmpty()) {
			State s = queue.poll();
			if(states.containsKey(s))
				continue;
			states.put(s, s.moves);
			
			int zx = s.zero % 3;
			int zy = s.zero / 3;
			
			if(zx < 2) {
				int[] v = s.vals.clone();
				v[s.zero] = v[s.zero + 1];
				v[s.zero + 1] = 0;
				queue.offer(new State(v, s.moves + 1, s.zero + 1));
			}
			if(zx > 0) {
				int[] v = s.vals.clone();
				v[s.zero] = v[s.zero - 1];
				v[s.zero - 1] = 0;
				queue.offer(new State(v, s.moves + 1, s.zero - 1));
			}
			if(zy < 2) {
				int[] v = s.vals.clone();
				v[s.zero] = v[s.zero + 3];
				v[s.zero + 3] = 0;
				queue.offer(new State(v, s.moves + 1, s.zero + 3));
			}
			if(zy > 0) {
				int[] v = s.vals.clone();
				v[s.zero] = v[s.zero - 3];
				v[s.zero - 3] = 0;
				queue.offer(new State(v, s.moves + 1, s.zero - 3));
			}
		}
		
		int sets = scanner.nextInt();
		for(int set = 1; set <= sets; set++) {
			int[] in = new int[9];
			for(int i = 0; i < 9; i++) {
				in[i] = scanner.nextInt();
			}
			
			
			Integer moves = states.get(new State(in, 0, 0));
			if(moves == null) {
				/*System.out.println(in[0] + " " + in[1] + " " + in[2]);
				System.out.println(in[3] + " " + in[4] + " " + in[5]);
				System.out.println(in[6] + " " + in[7] + " " + in[8]);
				break;*/
				throw new RuntimeException();
			}
			System.out.println(moves);
		}
	}
	
	static class State {
		int[] vals;
		int hash, moves, zero;
		
		public State(int[] vals, int moves, int zero) {
			this.vals = vals;
			this.moves = moves;
			this.zero = zero;
			
			hash = Arrays.hashCode(vals);
		}
		
		@Override
		public boolean equals(Object o) {
			if(!(o instanceof State))
				return false;
			State s = (State) o;
			for(int i = 0; i < vals.length; i++)
				if(vals[i] != s.vals[i])
					return false;
			return true;
		}
		
		@Override
		public int hashCode() {
			return hash;
		}
	}
}

