import java.util.*;


public class ac8670_prob6 {
	static class Point {
		int x, y;
		
		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}
		
		@Override
		public int hashCode() {
			return x ^ y;
		}
		
		@Override
		public boolean equals(Object o) {
			return o instanceof Point && x == ((Point) o).x && y == ((Point) o).y;
		}
	}
	static class Line {
		Point a, b;
		
		int minX, maxX, minY, maxY, rise, run;
		
		public Line(Point a, Point b) {
			this.a = a;
			this.b = b;
			
			minX = Math.min(a.x, b.x);
			maxX = Math.max(a.x, b.x);
			
			minY = Math.min(a.y, b.y);
			maxY = Math.max(a.y, b.y);
			
			rise = b.y - a.y;
			run = b.x - a.x;
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			Point p1 = new Point(scanner.nextInt(), scanner.nextInt());
			Point p2 = new Point(scanner.nextInt(), scanner.nextInt());
			Point p3 = new Point(scanner.nextInt(), scanner.nextInt());
			
			if(p1.equals(p2) && p2.equals(p3) && p1.x == 0 && p1.y == 0)
				break;
			
			int minX = Math.min(Math.min(p1.x, p2.x), p3.x);
			int maxX = Math.max(Math.max(p1.x, p2.x), p3.x);
			
			Line l1 = new Line(p1, p2);
			Line l2 = new Line(p2, p3);
			Line l3 = new Line(p1, p3);
			Line[] lines = { l1, l2, l3 };
			
			long total = 0;
			for(int x = minX + 1; x < maxX; x++) {
				Line a = null, b = null;
				for(Line la : lines) {
					if(x > la.minX && x < la.maxX) {
						a = la;
						for(Line lb : lines) {
							if(la == lb)
								continue;
							if((x >= lb.minX && x < lb.maxX) || (x > lb.minX && x <= lb.maxX)) {
								b = lb;
								break;
							}
						}
						break;
					}
				}
				if(a == null || b == null)
					continue;
				
				//System.out.println("A: (" + a.a.x + "," + a.a.y + ")->(" + a.b.x + "," + a.b.y + ") " + a.rise + "/" + a.run);
				//System.out.println("B: (" + b.a.x + "," + b.a.y + ")->(" + b.b.x + "," + b.b.y + ") " + b.rise + "/" + b.run);
				
				double ya = a.a.y + ((double) a.rise * (x - a.a.x) / a.run);
				double yb = b.a.y + ((double) b.rise * (x - b.a.x) / b.run);
				
				//System.out.println(x + " = " + ya + " " + yb);
				
				int diff = Math.max(0, (int) Math.ceil(Math.max(ya, yb) - Math.floor(Math.min(ya, yb))) - 1);
				total += diff;
			}
			
			System.out.println(total);
		}
	}
}

