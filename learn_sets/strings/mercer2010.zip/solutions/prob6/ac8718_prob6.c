#include <stdio.h>
#include <math.h>
int lcd(int a, int b) {return (b) ? lcd(b, a % b) : a;}
int abs(int a) {return (a < 0) ? -1 * a : a;}
int main() {
    int x[3], y[3], i, b;
    do {
        for (i = 0; i < (b = 3); ++i) scanf("%d %d", x + i, y + i);
        if (!x[0] && !x[1] && !x[2] && !y[0] && !y[1] && !y[2]) return 0;
        for (i = 0; i < 3; ++i) b += lcd(abs(y[i] - y[(i + 1) % 3]), abs(x[i] - x[(i + 1) % 3])) - 1;
        printf("%d%n", (int) round(.5 * abs(((x[0] - x[1]) * (y[0] - y[2]) - (x[0] - x[2]) * (y[0] - y[1]))) + 1 - (b / 2.0)));
    } while (1);
} // say what you want about C but I'd like to see one of you Java coders solve this in 13 lines

