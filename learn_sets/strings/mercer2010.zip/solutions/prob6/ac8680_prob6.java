/*
0 0 1 0 0 1
0 0 5 0 0 5
0 0 6 0 3 3
0 0 6 0 2 3
0 0 0 0 0 0

area: 0.5
b = 3 + -1 0 -1 = 1.0
ans:1.0

area: 12.5
b = 3 + -1 4 -1 = 5.0
ans:11.0
 */

import java.util.*;

public class ac8680_prob6 {

	public static void main(String[] args) {
		new ac8680_prob6();
	}
	
	public ac8680_prob6() {
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			Point p1 = new Point(sc.nextInt(), sc.nextInt());
			Point p2 = new Point(sc.nextInt(), sc.nextInt());
			Point p3 = new Point(sc.nextInt(), sc.nextInt());
			
			if(p1.x == 0 && p1.y == 0 && p2.x == 0 && p2.y == 0 && p3.x == 0 && p3.y == 0){
				break;
			}
			
			double area = getArea(p1, p2, p3);
			//System.out.println("area: " + area);
			
			double b = 3 + find(p1.x, p1.y, p2.x, p2.y) + find(p2.x, p2.y, p3.x, p3.y) + find(p1.x, p1.y, p3.x, p3.y);
			//System.out.println("b = 3 + " + find(p1.x, p1.y, p2.x, p2.y) + " " + find(p2.x, p2.y, p3.x, p3.y) + " " + find(p1.x, p1.y, p3.x, p3.y) + " = " + b);
			
			double ans = area - (b / 2.0) + 1;
			System.out.println((int) ans);
		}
		
		sc.close();
	}
		
	public class Point {
		int x, y;
		
		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
	
	public double getArea(Point a, Point b, Point c) {
		double sum = 0;
		
		sum += a.x*b.y - a.y*b.x;
		sum += b.x*c.y - b.y*c.x;
		sum += c.x*a.y - c.y*a.x;
		
		return Math.abs(sum / 2);
	}
	
	public int find(int x1, int y1, int x2, int y2) {
		int dx = Math.abs(x2 - x1);
		int dy = Math.abs(y2 - y1);
		if(dx == 0 || dy == 0){
			return Math.max(dx, dy) - 1;
		}
		else{
			return gcd(Math.abs(x2 - x1), Math.abs(y2 - y1)) - 1;
		}
	}
	
	public int gcd(int a, int b) {
		while(b != 0){
			int temp = a % b;
			a = b;
			b = temp;
		}
		
		return a;
	}
}

