//Ryan Kelsey
import java.util.Arrays;
import java.util.Scanner;

public class ac8706_prob6 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int x1 = scan.nextInt(), y1 = scan.nextInt(), x2 = scan.nextInt(), y2 = scan.nextInt(), x3 = scan.nextInt(), y3 = scan.nextInt();
		
		while(!(x1 == 0 && x2 == 0 && x3 == 0 && y1 == 0 && y2 == 0 && y3 == 0)) {
			Point[] points = {new Point(x1, y1), new Point(x2, y2), new Point(x3, y3)};
			Arrays.sort(points);
			
			double slope01 = (points[1].x - points[0].x == 0) ? Double.MAX_VALUE / 100 : (points[1].y - points[0].y) / (points[1].x - points[0].x);
			double b01 = points[0].y - slope01 * points[0].x;
			double slope12 = (points[2].x - points[1].x == 0) ? Double.MAX_VALUE / 100 : (points[2].y - points[1].y) / (points[2].x - points[1].x);
			double b12 = points[1].y - slope12 * points[1].x;
			double slope20 = (points[0].x - points[2].x == 0) ? Double.MAX_VALUE / 100 : (points[0].y - points[2].y) / (points[0].x - points[2].x);
			double b20 = points[2].y - slope20 * points[2].x;
			
			int count = 0;
			int p = 1;
			if((int)points[1].x == (int)points[2].x)
				p = 0;
			
			for(int i = (int)points[0].x + 1; i < (int)points[1].x + p; i++)
				count += roundDown(Math.max(slope01 * i + b01, slope20 * i + b20)) - roundUp(Math.min(slope01 * i + b01, slope20 * i + b20)) + 1;
			
			for(int i = (int)points[1].x + 1; i < (int)points[2].x; i++)
				count += roundDown(Math.max(slope12 * i + b12, slope20 * i + b20)) - roundUp(Math.min(slope12 * i + b12, slope20 * i + b20)) + 1;
			
			System.out.println(count);
			x1 = scan.nextInt();
			y1 = scan.nextInt();
			x2 = scan.nextInt();
			y2 = scan.nextInt();
			x3 = scan.nextInt();
			y3 = scan.nextInt();
		}
		scan.close();
	}
	
	public static int roundDown(double d) {
		if(Math.abs(d - Math.floor(d)) <= 1e-9)
			return (int)Math.floor(d) - 1;
		return (int)Math.floor(d);
	}
	
	public static int roundUp(double d) {
		if(Math.abs(d - Math.ceil(d)) <= 1e-9)
			return (int)Math.ceil(d) + 1;
		return (int)Math.ceil(d);
	}
}

class Point implements Comparable<Point> {
	public double x, y;
	
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public int compareTo(Point other) {
		return Double.compare(this.x, other.x);
	}
}
