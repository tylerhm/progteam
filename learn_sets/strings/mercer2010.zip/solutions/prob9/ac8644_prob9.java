import java.util.Scanner;

public class ac8644_prob9 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int sets = scanner.nextInt();
		for(int set = 1; set <= sets; set++) {
			String s1 = scanner.next();
			String s2 = scanner.next();
			
			System.out.print("Case #" + set + ": ");
			if(s1.length() != s2.length()) {
				System.out.println("NO");
				continue;
			}
			
			String s = s1 + s1;
			if(s.contains(s2)) {
				System.out.println("YES");
				continue;
			}
			
			s2 = reverse(s2);
			System.out.println(s.contains(s2) ? "YES" : "NO");
		}

		scanner.close();

	}

	private static String reverse(String s) {
		if(s.length() == 0)
			return s;
		char[] c = s.toCharArray();
		
		for(int i = 0; i < c.length / 2; i++) {
			char temp = c[i];
			c[i] = c[c.length - i - 1];
			c[c.length - i - 1] = temp;
		}
		
		return new String(c);
	}
}

