import java.util.*;

public class ac8700_prob9 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int loopCount = in.nextInt();
		int lc;
		StringBuilder a, b;
		
		for(lc = 0; lc < loopCount; lc++){
			
			//Input
			a = new StringBuilder(in.next());
			b = new StringBuilder(in.next());
			
			
			//Solve & Output
			b.append(b);
			
			System.out.printf("Case #%d: ", lc + 1);
			if(a.length() == b.length() / 2 && (b.toString().contains(a) || b.reverse().toString().contains(a)))
				System.out.println("YES");
			else
				System.out.println("NO");
		}
		
		in.close();
	}

}

