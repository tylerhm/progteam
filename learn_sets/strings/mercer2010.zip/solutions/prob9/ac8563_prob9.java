import java.util.*;

public class ac8563_prob9 {

	public static void main(String[] args) {
		new ac8563_prob9();
	}
	
	public ac8563_prob9() {
		Scanner sc = new Scanner(System.in);
		
		int t = sc.nextInt();
		for(int tc = 1; tc <= t; tc++){
			String a = sc.next();		
			String b = sc.next();
			
			if(a.length() != b.length()){
				System.out.println("Case #" + tc + ": NO");
				continue;
			}
			
			a += a;
			String bR = reverse(b);

			boolean found = false;
			if(a.indexOf(b) != -1 || a.indexOf(bR) != -1){
				found = true;
			}		
						
			if(found){
				System.out.println("Case #" + tc + ": YES");
			}
			else{
				System.out.println("Case #" + tc + ": NO");
			}
			
		}
		
		sc.close();
	}
	
	public String reverse(String str) {
		return new StringBuilder(str).reverse().toString();
	}
}

