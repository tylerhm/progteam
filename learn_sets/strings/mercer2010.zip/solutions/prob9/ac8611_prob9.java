import java.util.Scanner;


public class ac8611_prob9 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		scan.nextLine();
		for(int i =0; i < runs; i++) {
			String first = scan.nextLine();
			String second = scan.nextLine();

			char start = first.charAt(0);
			boolean works = false;
			if(first.length() == second.length())
				for(int j =0; j < second.length(); j++){
					if(second.charAt(j)==start){
						if(forwards(first,second,j)){
							works = true;
							break;
						}else if(backwards(first,second,j)){
							works = true;
							break;
						}
					}
				}
			System.out.println("Case #" + (i+1) + ": " + (works ? "YES" : "NO"));
		}
	}

	private static boolean backwards(String first, String second, int s) {
		boolean valid = true;
		int index = s+1;
		for(int i = 0; i < second.length(); i++){
			index--;
			if(index == -1) {
				index = second.length()-1;
			}
			if(second.charAt(index) != first.charAt(i)){
				valid = false;
				break;
			}
		}
		return valid;
	}

	private static boolean forwards(String first, String second, int s) {
		boolean valid = true;
		for(int i = 0; i < second.length(); i++){
			if(second.charAt((i+s)%second.length()) != first.charAt(i%first.length())){
				valid = false;
				break;
			}
		}
		return valid;
	}

}

