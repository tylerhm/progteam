//Ryan Kelsey
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ac8705_prob5 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		
		problem:for(int z = 1; z <= runs; z++) {
			String moveStr = scan.next();
			List<Move> moves = new ArrayList<Move>();
			for(int i = 0; i < moveStr.length();) {
				String s = "";
				while(Character.isDigit(moveStr.charAt(i))) {
					s += moveStr.substring(i, i + 1);
					i++;
				}
				moves.add(new Move(Integer.parseInt(s), moveStr.charAt(i++) == 'R'));
			}
			
			trying:for(int width = 2; width <= 51; width++) {
				Dot[][] grid = new Dot[51][width];
				for(int i = 0; i < 51; i++)
					for(int j = 0; j < width; j++)
						grid[i][j] = new Dot();
				int[][] boxes = new int[50][width - 1];
				for(int[] arr : boxes)
					Arrays.fill(arr, -1);
				int rows = 1;
				
				for(int i = 0, turn = 0; i < moves.size(); i++, turn = 1 - turn) {
					int r = moves.get(i).pos / width;
					if(r > 50) continue trying;
					int c = moves.get(i).pos % width;
					rows = Math.max(rows, r);
					
					if(moves.get(i).dir) {
						grid[r][c].right = true;
						if(r - 1 >= 0 && c + 1 < width && grid[r - 1][c].right && grid[r - 1][c].down && grid[r - 1][c + 1].down)
							boxes[r - 1][c] = turn;
						if(r + 1 <= rows && c + 1 < width && grid[r + 1][c].right && grid[r][c].down && grid[r][c + 1].down)
							boxes[r][c] = turn;
					} else {
						grid[r][c].down = true;
						if(c - 1 >= 0 && grid[r][c - 1].right && grid[r][c - 1].down && grid[r + 1][c - 1].right)
							boxes[r][c - 1] = turn;
						if(c + 1 < width && grid[r][c].right && grid[r][c + 1].down && grid[r + 1][c].right)
							boxes[r][c] = turn;
					}
				}
				
				int a = 0, b = 0;
				for(int r = 0; r < rows; r++) {
					for(int c = 0; c < width - 1; c++) {
						if(boxes[r][c] == 0)
							a++;
						else if(boxes[r][c] == 1)
							b++;
						else
							continue trying;
					}
				}
				
				System.out.printf("%d %dX%d %s%n", z, width, rows + 1, (a == b) ? "TIE" : (a > b) ? "A WINS" : "B WINS");
				continue problem;
			}
		}
		scan.close();
	}
}

class Dot {
	public boolean right, down;
}

class Move {
	public int pos;
	public boolean dir;
	
	public Move(int pos, boolean dir) {
		this.pos = pos;
		this.dir = dir;
	}
}
