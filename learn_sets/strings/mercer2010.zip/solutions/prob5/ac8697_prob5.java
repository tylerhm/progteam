import java.util.*;

public class ac8697_prob5
{
	public static void main(String[] arg)
	{
		ac8697_prob5 a = new ac8697_prob5();
		a.doit();
	}
	public void doit()
	{
		Scanner in = new Scanner(System.in);
		int cases = in.nextInt();
		for(int cc = 1; cc <= cases; cc++)
		{
			String temp = in.next();
			ArrayList<Pair> moves = parse(temp);
			System.out.print(cc + " ");
			String dim = getDim(moves);
			System.out.print(dim + " ");
			solve(dim, moves);
		}
	}
	public void solve(String dim, ArrayList<Pair> moves)
	{
		String[] temp = dim.split("X");
		int col = Integer.parseInt(temp[0]);
		int row = Integer.parseInt(temp[1]);
		int[] players = new int[2];
		HashSet<String> hs = new HashSet<String>();
		for(int i = 0; i < moves.size(); i++)
		{
			hs.add(moves.get(i).hash());
			if(moves.get(i).dir == 'R')
			{
				if(hs.contains(moves.get(i).mag-col+"R"))
				{
					if(hs.contains(moves.get(i).mag-col+"D") && hs.contains(moves.get(i).mag-col+1+"D"))
						players[i%2]++;
				}
				if(hs.contains(moves.get(i).mag+col+"R"))
				{
					if(hs.contains(moves.get(i).mag+"D") && hs.contains(moves.get(i).mag+1+"D"))
						players[i%2]++;
				}
			}
			else
			{
				if(hs.contains(moves.get(i).mag+1+"D"))
				{
					if(hs.contains(moves.get(i).mag+"R") && hs.contains(moves.get(i).mag+col+"R"))
						players[i%2]++;
				}
				if(hs.contains(moves.get(i).mag-1+"D"))
				{
					if(hs.contains(moves.get(i).mag-1+"R") && hs.contains(moves.get(i).mag+col-1+"R"))
						players[i%2]++;
				}
			}
		}
		//System.out.println(Arrays.toString(players));
		if(players[0] > players[1])
			System.out.println("A WINS");
		else if(players[0] < players[1])
			System.out.println("B WINS");
		else
			System.out.println("TIE");
	}
	public ArrayList<Pair> parse(String temp)
	{
		ArrayList<StringBuilder> answer = new ArrayList<StringBuilder>();
		for(int i = 0; i < temp.length(); i++)
		{
			if(i == 0)
				answer.add(new StringBuilder());
			answer.get(answer.size()-1).append(temp.charAt(i));
			if(temp.charAt(i) == 'R' || temp.charAt(i) == 'D')
				answer.add(new StringBuilder());
		}
		answer.remove(answer.size()-1);
		ArrayList<Pair> ans = new ArrayList<Pair>();
		for(int i = 0; i < answer.size(); i++)
		{
			ans.add(new Pair(Integer.parseInt(answer.get(i).substring(0, answer.get(i).length()-1)), answer.get(i).charAt(answer.get(i).length()-1)));
		}
		return ans;
	}
	public String getDim(ArrayList<Pair> moves)
	{
		int r = 0, d = 0;
		for(int i = 0; i < moves.size(); i++)
		{
			if(moves.get(i).dir == 'R')
				r = Math.max(r, moves.get(i).mag);
			else
				d = Math.max(d, moves.get(i).mag);
		}
		int col = r + 1 - d;
		int row = (r+2)/col;
		return col+"X"+row;
	}
	class Pair
	{
		public int mag;
		public char dir;
		public Pair(int a, char b)
		{	
			mag = a;
			dir = b;
		}
		public String hash()
		{
			StringBuilder answer = new StringBuilder();
			answer.append(mag);
			answer.append(dir);
			return answer.toString();
		}
		public String toString()
		{
			StringBuilder ans = new StringBuilder();
			ans.append(mag + " " + dir);
			return ans.toString();
		}
	}
}
