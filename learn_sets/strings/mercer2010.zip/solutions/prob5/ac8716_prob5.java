import java.util.*;

public class ac8716_prob5 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int cases, x, y, A, B;
		String str;
		String[] temp;
		int[] point;
		boolean[][] grid;
		char[] dir;
		cases = Integer.parseInt(in.nextLine());
		for (int c = 1; c <= cases; ++c) {
			grid = new boolean[5000][2];
			str = in.nextLine();
			if (str.isEmpty()) {
				System.out.printf("%d 1X1 TIE%n", c);
				continue;
			}
			temp = str.split("[R,D]");
			point = new int[temp.length];
			for (int i = 0; i < point.length; ++i) point[i] = Integer.parseInt(temp[i]);
			temp = str.split("[0-9]+");
			dir = new char[temp.length];
			for (int i = x = y = 1; i < dir.length; ++i) dir[i - 1] = temp[i].charAt(0);
			for (int i = 0; i < point.length; ++i) grid[point[i]][(dir[i] == 'R') ? 0 : 1] = true;
			for (int i = 0; i < 5000; ++i) if (grid[i][0] || grid[i][1]) A = (!grid[i][0]) ? ++y : (!grid[i][1]) ? ++x : 0;
			grid = new boolean[5000][2];
			for (int i = A = B = 0; i < point.length; ++i) {
				if (dir[i] == 'R') {
					grid[point[i]][0] = true;
					if (point[i] >= x && grid[point[i] - x][0] && grid[point[i] - x][1] && grid[point[i] - x + 1][1]) {
						if (i % 2 == 0) ++A;
						else ++B;
					}
					if (point[i] < (y - 1) * x && grid[point[i]][1] && grid[point[i] + 1][1] && grid[point[i] + x][0]) {
						if (i % 2 == 0) ++A;
						else ++B;
					}
				}
				else {
					grid[point[i]][1] = true;
					if (point[i] % x != 0 && grid[point[i] - 1][0] && grid[point[i] - 1][1] && grid[point[i] + x - 1][0]) {
						if (i % 2 == 0) ++A;
						else ++B;
					}
					if (point[i] + 1 % x != 0 && grid[point[i]][0] && grid[point[i] + 1][1] && grid[point[i] + x][0]) {
						if (i % 2 == 0) ++A;
						else ++B;
					}
				}
			}
			System.out.printf("%d %dX%d %s%n", c, x, y, (A == B) ? "TIE" : (A > B) ? "A WINS" : "B WINS");
		}
		in.close();
	}
}

