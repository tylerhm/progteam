//Ryan Kelsey
import java.util.Scanner;

public class ac8719_prob11 {
	public static final long[][] START = {{1L, 1L}, {1L, 0L}};
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		long n = scan.nextLong(), m = scan.nextLong();
		
		while(!(n == 0 && m == 0)) {
			long[][] res = matrixMultiply(START, fastMatrixExpo(START, n, m), m);
			System.out.println(res[0][0]);
			n = scan.nextLong();
			m = scan.nextLong();
		}
		scan.close();
	}
	
	public static long[][] fastMatrixExpo(long[][] matrix, long exp, long mod) {
		if(exp == 1) {
			return matrix;
		}
		
		if(exp % 2L == 0) {
			long[][] curMatrix = fastMatrixExpo(matrix, exp / 2L, mod);
			return matrixMultiply(curMatrix, curMatrix, mod);
		} else {
			long[][] curMatrix = fastMatrixExpo(matrix, exp / 2L, mod);
			return matrixMultiply(matrix, matrixMultiply(curMatrix, curMatrix, mod), mod);
		}
	}
	
	public static long[][] matrixMultiply(long[][] a, long[][] b, long mod) {
		return new long[][] {{(a[0][0] * b[0][0] + a[0][1] * b[1][0]) % mod, (a[0][0] * b[0][1] + a[0][1] * b[1][1]) % mod}, {(a[1][0] * b[0][0] + a[1][1] * b[1][0]) % mod, (a[1][0] * b[0][1] + a[1][1] * b[1][1]) % mod}};
	}
}
