import java.util.*;

public class ac8623_prob11 {
	static long mod;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		long[][] ans = new long[2][2];
		long[][] mat = new long[2][2];
		long[][] mult = new long[2][2];
		long length;
		
		length = in.nextLong();
		mod = in.nextInt();
		
		while(!(length == 0 && mod == 0)){
			//Init mat & mult
			mat[0][0] = 2;
			mat[0][1] = mat[1][0] = mat[1][1] = 1;
			
			mult[0][0] = mult[0][1] = mult[1][0] = 1;
			mult[1][1] = 0;
			
			ans = mat;
			
			
			//Solve
			if(length > 1)
				ans = matMult(mat, solver(mult, length - 1));
			
			
			//Output
			System.out.println(ans[0][0]);
			
			
			//Next input
			length = in.nextLong();
			mod = in.nextLong();
		}
		
		in.close();
	}
	
	static long[][] solver(long[][] mat, long length){
		if(length == 1)
			return mat;
		
		if(length % 2 == 0){
			long[][] ans = solver(mat, length / 2);
			return matMult(ans, ans);
		}
		
		return matMult(mat, solver(mat, length - 1));
	}

	static long[][] matMult(long[][] mat, long[][] mult){
		long[][] ans = new long[2][2];
		
		ans[0][0] = (mat[0][0] * mult[0][0] + mat[0][1] * mult[1][0]) % mod;
		ans[0][1] = ans[1][0] = (mat[0][0] * mult[1][0] + mat[0][1] * mult[1][1]) % mod;
		ans[1][1] = (mat[1][0] * mult[0][1] + mat[1][1] * mult[1][1]) % mod;
		
		return ans;
	}
}

