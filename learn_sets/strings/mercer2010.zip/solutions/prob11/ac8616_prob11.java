import java.util.*;
import java.math.*;
public class ac8616_prob11
{
	public static void main(String[] arg)
	{
		Scanner in = new Scanner(System.in);
		String temp =in.next();
		String temp2 = in.next();
		while(!temp.equals("0") || !temp2.equals("0"))
		{
			BigInteger k = new BigInteger(temp);
			BigInteger mod = new BigInteger(temp2);
			BigInteger[][] fib = new BigInteger[2][2];
			fib[0][0] = BigInteger.valueOf(1);
			fib[0][1] = BigInteger.valueOf(1);
			fib[1][0] = BigInteger.valueOf(1);
			fib[1][1] = BigInteger.valueOf(0);
			BigInteger[][] answer = fastexpo(fib, k, mod);
			BigInteger[][] x = new BigInteger[2][1];
			x[0][0] = BigInteger.valueOf(1);
			x[1][0] = BigInteger.valueOf(1);
			BigInteger[][] b = multiply(answer, x, mod);
			//System.out.println(b[0][0]);
			//System.out.println(b[1][0]);
			
			//System.out.println(b[1][0]);
			//System.out.println(answer[0][0]);
			//System.out.println(answer[0][1]);
			//System.out.println(answer[1][0]);
			//System.out.println(answer[1][1]);
			/*
			for(int i= 0; i < answer.length; i++)
			{
				for(int j = 0; j < answer[i].length; j++)
					System.out.print(answer[i][j] + " ");
				System.out.println();
			}
			System.out.println();
			*/
			System.out.println(b[0][0]);
			temp = in.next(); temp2 = in.next();
		}
	}
	public static BigInteger[][] fastexpo(BigInteger[][] mat, BigInteger k, BigInteger mod)
	{
		if(k.equals(BigInteger.valueOf(1)))
			return mat;
		BigInteger[][] answer = fastexpo(mat, k.divide(BigInteger.valueOf(2)), mod);
		answer = multiply(answer, answer, mod);
		if(k.mod(BigInteger.valueOf(2)).equals(BigInteger.valueOf(1)))
			answer = multiply(answer, mat, mod);
		return answer;
	}
	public static BigInteger[][] multiply(BigInteger[][] a, BigInteger[][] x, BigInteger mod)
	{
		BigInteger[][] answer = new BigInteger[a.length][x[0].length];
		for(int i = 0; i < answer.length; i++)
			for(int j = 0; j < answer[i].length; j++)
				answer[i][j] = new BigInteger("0");
		for(int i= 0; i < answer.length; i++)
		{
			for(int j = 0; j < answer[i].length; j++)
			{
				for(int k = 0; k < x.length; k++)
				{
					answer[i][j] = answer[i][j].add(a[i][k].multiply(x[k][j])).mod(mod);
				}
			}
		}
		return answer;
	}
}
