import java.util.Scanner;

/*
1 10
2 10
3 10
4 10
5 10
6 8
0 0


 */
public class ac8695_prob11 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		long n = in.nextLong();
		long m = in.nextLong();
		
		while(n != 0 || m != 0){
			long[][] a = new long[2][2];
			a[0][0] = 1; a[0][1] = 1; a[1][0] = 1; a[1][1] = 0;
			System.out.println(fastMat(a, n+2, m));
			n = in.nextLong();
			m = in.nextLong();
		}
	}
	
	public static long fastMat(long[][] a, long n, long m){
		long[][] ident = new long[2][2];
		ident[0][0] = 1;
		ident[1][1] = 1;
		
		while(n>0){
			if(n%2==0){
				mult(a,a, m);
				n/=2;
			}
			else{
				mult(ident, a, m);
				n--;
			}
		}
		return ident[0][1];
	}
	
	public static void mult(long[][] a, long[][] b, long m){
		long c = a[0][0]*b[0][0] + a[0][1]*b[1][0];
		long d = a[0][0]*b[0][1] + a[0][1]*b[1][1];
		long e = a[1][0]*b[0][0] + a[1][1]*b[1][0];
		long f = a[1][0]*b[0][1] + a[1][1]*b[1][1];
		a[0][0] = c%m;
		a[0][1] = d%m;
		a[1][0] = e%m;
		a[1][1] = f%m;

	}

}

