import java.util.Scanner;


public class ac8587_prob2 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int num = in.nextInt();
		for (int i = 1; i <= num; i++) {
			String n1 = in.next();
			String n2 = in.next();
			if(n1.equals(n2)){
				System.out.println("Case #" + i + ": YES");
				continue;
			}
			if(n1.length() != n2.length()){
				System.out.println("Case #" + i + ": NO");
				continue;
			}
			int p = 1;
			String pre = n1.substring(0, 1);
			while(true){
				String temp = n1.substring(0,p);
				if(!n2.contains(temp))break;
				pre = temp;
				p++;
			}
			boolean b = true;
			if(pre.length() == 1)b = false;
			else{
				if(!n2.startsWith(n1.substring(pre.length())))
					b = false;
			}
			if(!b)
			{
				n1 = (new StringBuffer(n1)).reverse().toString();
				if(n1.equals(n2)){
					System.out.println("Case #" + i + ": YES");
					continue;
				}
				p = 1;
				pre = n1.substring(0, 1);
				while(true){
					String temp = n1.substring(0,p);
					if(!n2.contains(temp))break;
					pre = temp;
					p++;
				}
				b = true;
				if(pre.length() == 1)b = false;
				else{
					if(!n2.startsWith(n1.substring(pre.length())))
						b = false;
				}
				
			}
			//System.out.println(pre);
			if(b)
				System.out.println("Case #" + i + ": YES");
			else
				System.out.println("Case #" + i + ": NO");
			
			
		}
	}
}

