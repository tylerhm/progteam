import java.util.Scanner;

public class ac8569_prob2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int numNecks = in.nextInt();
		in.nextLine();

		for (int i = 1; i <= numNecks; i++) {
			boolean identical;
			String neck1 = in.nextLine();
			String neck2 = in.nextLine();

			if (neck1.length() != neck2.length())
				identical = false;
			else {
				int charCount1[] = new int[26];
				int charCount2[] = new int[26];

				for (int j = 0; j < neck1.length(); j++) {
					charCount1[neck1.charAt(j) - 'a']++;
					charCount2[neck2.charAt(j) - 'a']++;
				}
				
				identical = true;
				for (int j = 0; j < 26; j++) {
					if (charCount1[j] != charCount2[j]) {
						identical = false;
						break;
					}
				}
			}
			
			System.out.print("Case #" + i + ": ");
			if (identical)
				System.out.println("YES");
			else
				System.out.println("NO");
			
		}
	}

}

