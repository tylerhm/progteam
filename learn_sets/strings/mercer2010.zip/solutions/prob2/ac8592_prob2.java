import java.util.Scanner;


public class ac8592_prob2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		scan.nextLine();
		for(int i =0; i < runs; i++) {
			String first = scan.nextLine();
			String second = scan.nextLine();
			StringBuilder s = new StringBuilder();
			s.append(second);
			s.reverse();

			String reversed = s.toString();
			//Brute force
			char start = first.charAt(0);
			boolean works = false;
			if(first.length() == second.length())
				for(int j =0; j < second.length(); j++){
					if(second.charAt(j)==start){
						if(forwards(first,second,j)){
							works = true;
							break;
						}else if(forwards(first,reversed,second.length()-j-1)){
							works = true;
							break;
						}

					}
				}
			System.out.println("Case #" + (i+1) + ": " + (works ? "YES" : "NO"));
		}
	}

	private static boolean forwards(String first, String second, int s) {
		boolean valid = true;
		for(int i = 0; i < second.length(); i++){
			if(second.charAt((i+s)%second.length()) != first.charAt(i%first.length())){
				valid = false;
				break;
			}
		}
		return valid;
	}

}

