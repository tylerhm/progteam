//Ryan Kelsey
import java.util.Scanner;

public class ac8702_prob2 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		
		for(int z = 1; z <= runs; z++) {
			String a = scan.next();
			StringBuilder b = new StringBuilder(scan.next());
			String forward = b.toString() + b.toString();
			String backward = b.reverse().toString() + b.toString();
			
			if(a.length() == b.length() && (forward.indexOf(a) >= 0 || backward.indexOf(a) >= 0))
				System.out.printf("Case #%d: YES%n", z);
			else
				System.out.printf("Case #%d: NO%n", z);
		}
		scan.close();
	}
}
