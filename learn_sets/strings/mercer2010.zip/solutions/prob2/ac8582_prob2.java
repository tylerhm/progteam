import java.awt.Checkbox;
import java.util.Scanner;


public class ac8582_prob2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		scan.nextLine();
		for(int i  =0 ; i < runs; i++) {
			String string1 = scan.nextLine();
			String string2 = scan.nextLine();
			System.out.print("Case #" + (i+1) + ": ");
			if(check(string1, string2)) {
				System.out.println("YES");
			}
			else {
				System.out.println("NO");
			}
		}
	}

	static boolean check(String str1, String str2) {
		if(str1.length() != str2.length()) {
			return false;
		}

		for(int w = 0; w < str1.length(); w++) {
			if(compare( str1,  str2, w) || compareBackwards( str1,  str2, w) ) {
				return true;
			}
		}
		return false;
	}

	static boolean compare(String str1, String str2, int index) {
		for(int i = 0; i < str1.length(); i++) {
			if(str1.charAt(index) != str2.charAt(i)) {
				return false;
			}
			index++;
			if(index == str1.length()) {
				index = 0;
			}
		}
		return true;
	}
	

	static boolean compareBackwards(String str1, String str2, int index) {
		for(int i = 0; i < str1.length(); i++) {
			if(str1.charAt(index) != str2.charAt(i)) {
				return false;
			}
			index--;
			if(index == -1) {
				index = str1.length()-1;
			}
		}
		return true;
	}
}

/*
4
lana
nala
abcdefg
efgabcd
abcdefg
bagfedc
abcdefg
opqrstu
 */

