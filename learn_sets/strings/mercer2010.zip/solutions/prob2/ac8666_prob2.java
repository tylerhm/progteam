import java.util.Scanner;
public class ac8666_prob2 {
	public static void main(String[] args) throws Exception{
		Scanner stdin = new Scanner(System.in);
		int cases = stdin.nextInt();
		boolean match = false; 
		for(int i = 0; i < cases; i++){
			String  first = stdin.next(); 
			String sec = stdin.next(); 
			String temp = "";
			
			
			int n = first.length();
			match = false;
			while(n != 0){
				first = first.substring(1) + first.charAt(0); 
				//System.out.println("Result is " +first); 
				
				if(temp.contains(sec) || reverse(first).contains(sec)){
					match = true; 
				}
				temp = first.charAt(first.length()-1) + first.substring(0, first.length()-1); 
				//System.out.println("temp is " +temp); 
				n--;
			}
			if(first.length() != sec.length()){
				match = false; 
			}
			if(match == false){
				System.out.println("Case #" + (i+ 1) + ": NO");
			}
			else if(match == true){
				System.out.println("Case #" + (i+ 1) + ": YES");
			}
		}
	}
	public static String reverse(String str){
		String rev = "";
		int n = str.length(); 
		for(int i = n-1; i>=0; i--){
			rev = rev + str.charAt(i); 
			//System.out.println(rev); 
		}
		return rev; 
	}
}

