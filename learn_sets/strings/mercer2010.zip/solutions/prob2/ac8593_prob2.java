import java.util.*;

public class ac8593_prob2 {
	
	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		int cases = in.nextInt();
		
		for(int i = 0; i < cases; i++) {
			String neck1 = in.next();
			String neck2 = in.next();
			
			neck1 += neck1;
			
			if (match(neck1, neck2) || match (neck1, reverse(neck2)))
				System.out.println("Case #" + (i+1) + ": YES");
			
			else
				System.out.println("Case #" + (i+1) + ": NO");
		}
		
		in.close();
	}
	
	static boolean match(String s1, String s2) {
		if (s1.length()/2 != s2.length())
			return false;
		
		for (int i = 0; i < s1.length() - s2.length(); i++) {
			if (s1.substring(i, i + s2.length()).equals(s2))
				return true;
		}
		
		return false;
	}
	
	static String reverse(String s) {
		String n = "";
		
		for (int i = s.length() - 1; i >= 0; i--) {
			n += s.charAt(i);
		}
		
		return n;
	}
}
