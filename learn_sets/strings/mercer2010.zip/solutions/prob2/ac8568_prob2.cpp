#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
    int test_cases;
    cin >> test_cases;

    string a, b;
    int c[26];
    int d[26];

    for(int z = 0; z < test_cases; z++)
    {
        cin >> a;
        cin >> b;

        for(int i = 0; i < 26; i++)
        {
            c[i] = 0;
            d[i] = 0;
        }

        for(int i = 0 ; i < a.size(); i++)
        {
            c[a[i] - 'a']++;
        }

        for(int i = 0 ; i < b.size(); i++)
        {
            d[b[i] - 'a']++;
        }

        bool correct = true;
        for(int i = 0; i < 26; i++)
        {
            if(c[i] != d[i])
                correct = false;
        }

        cout << "Case #" << (z+1) << ": " << (correct? "YES" : "NO") << endl;
    }
}

