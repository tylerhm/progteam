import java.util.Scanner;
/*
4
lana
nala
abcdefg
efgabcd
abcdefg
bagfedc
abcdefg
opqrstu

 */

public class ac8585_prob2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int cases = in.nextInt();
		in.nextLine();
		
		for(int i = 1; i <= cases; i++){
			
			String one = in.nextLine();
			String two = in.nextLine();
			
			boolean match = false;
			
			int len1 = one.length();
			int len2 = two.length();
			
			if(len1 != len2 || (len1 == 1 && !one.equals(two))){
				System.out.print("Case #" + i + ": ");
				System.out.println("NO");
				continue;
			}
			
			String temp = two;
			String temp2 = reverse(one);
			for(int j = 0; j <= len2; j++){
				temp = rotate(temp);				
				//System.err.println(temp + " "+ two + " " + temp2 + " " + one);
				if(temp.equals(temp2) || temp.equals(one)) {match = true; break;}
			}
			System.out.print("Case #" + i + ": ");
			if(match) System.out.println("YES");
			else System.out.println("NO");
		}
	}
	
	public static String reverse(String arg){
		String temp = "";
		for(int i = arg.length()-1; i >=0; i-- ){
			temp += arg.charAt(i);
		}
		return temp;
	}
	
	public static String rotate(String arg){
		return arg.substring(1) + arg.charAt(0);
	}

}

