import java.util.Arrays;
import java.util.Scanner;

public class ac8575_prob2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = Integer.parseInt(in.nextLine());
		for (int t = 0; t < numCases; t++) {
			char word1[] = in.nextLine().toCharArray();
			char word2[] = in.nextLine().toCharArray();
			Arrays.sort(word1);
			Arrays.sort(word2);
			if (word1.length != word2.length)
				System.out.println("Case #" + (t + 1) + ": NO");
			else {
				boolean broke = false;
				for (int i = 0; i < word1.length; i++) {
					if (word1[i] != word2[i]) {

						System.out.println("Case #" + (t + 1) + ": NO");
						broke = true;
						break;
					}
				}
				if (!broke)
					System.out.println("Case #" + (t + 1) + ": YES");
			}
		}

		in.close();

	}

}

