import java.io.*;
import java.util.*;

public class ac8570_prob2 {
	public static void main(String[] args) throws IOException {
		Scanner in = new Scanner(System.in);
		int cases = in.nextInt();
		for(int cc = 0; cc < cases; cc++) {
			String s1 = in.next();
			String s2 = in.next();
			int ind = s2.indexOf(s1.charAt(0));
			boolean match = false;
			if(s1.length()==s2.length())
				while(!match && ind >= 0) {
					boolean okay = true;
					for(int i = 0; i < s1.length() && okay; i++) {
						if(s1.charAt(i)!=s2.charAt((i+ind)%s2.length()))
							okay = false;
					}
					if(!okay) {
						okay = true;
						for(int i = 0; i < s1.length() && okay; i++) {
							int n = ind-i;
							if(n < 0) n+=s2.length();
							if(s1.charAt(i)!=s2.charAt(n))
								okay = false;
						}
					}
					match = okay;
					ind = s2.indexOf(s1.charAt(0), ind+1);
				}
			
			System.out.printf("Case #%d: %s%n", cc+1, match ? "YES" : "NO");
		}
	}
}

