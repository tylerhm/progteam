/*
4
a
a
ab
ba
aaa
a
bb
bb
lana
nala
abcdefg
efgabcd
abcdefg
bagfedc
abcdefg
opqrstu
 */

import java.util.*;

public class ac8560_prob2 {

	public static void main(String[] args) {
		new ac8560_prob2();
	}
	
	public ac8560_prob2() {
		Scanner sc = new Scanner(System.in);
		
		int t = sc.nextInt();
		for(int tc = 1; tc <= t; tc++){
			String a = sc.next();
			a += a;
			
			String b = sc.next();
			String bR = reverse(b);

			boolean found = false;
			if(a.indexOf(b) != -1 || a.indexOf(bR) != -1){
				found = true;
			}		
			
			if(a.length() / 2 != b.length()){
				found = false;
			}
			
			if(found){
				System.out.println("Case #" + tc + ": YES");
			}
			else{
				System.out.println("Case #" + tc + ": NO");
			}
			
		}
		
		sc.close();
	}
	
	public String reverse(String str) {
		return new StringBuilder(str).reverse().toString();
	}
}

