import java.util.Arrays;
import java.util.Scanner;


public class ac8574_prob10 {
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		boolean[] nums = new boolean[2500];
		int[] primes = new int[256];
		Arrays.fill(nums, true);
		int c = 0;
		for(int i = 2; i <= 2500; i++){
			if(nums[i]){
				primes[c] = i;
				c++;
				if(c >255)break;
				for (int j = i+i; j < nums.length; j+=i) {
					nums[j] = false;
				}
			}
		}
		int n = in.nextInt();
		for(int i = 0; i < n; i++)
		{
			int t = in.nextInt();
			int sum = 0;
			for (int j = 0; j <= t; j++) {
				sum += primes[j];
			}
			System.out.println(sum);
		}
	}

}

