import java.util.Arrays;
import java.util.Scanner;


public class ac8689_prob10 {
	public static void main(String[] args) throws Exception{
		Scanner stdin = new Scanner(System.in);
		
		int N = stdin.nextInt();
		for(int i = 0; i < N; i++){
			int nthP = stdin.nextInt() + 2; 
			int sum = 0; 
			int[] Primes = new int[100000]; 
			
			boolean[] primeval; 
			primeval = primes(1000000); 
			
			int countp = 0; 
			
			for(int j = 0; j < 1000000; j++){
				if(primeval[j] == true){
					countp++; 
					Primes[countp] = j; 
				}
			}
			for(int j = 0; j < nthP; j++){ 	
					sum += Primes[j]; 
				
			}
			System.out.println(sum);
		}
		
	}
	public static boolean[] primes(int n){
		boolean[] primes = new boolean[n+1];
		Arrays.fill(primes, true);
		
		primes[0] = false;
		primes[1] = false;
		for(int i = 2; i < Math.sqrt(n) + 1; i++){
			for(int j = 2*i; j <= n; j+=i){
				if(primes[i]){
					primes[j] = false; 
				}
			}
		}
		return primes; 
	}

}

