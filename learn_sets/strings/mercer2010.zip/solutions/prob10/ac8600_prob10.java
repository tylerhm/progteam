import java.util.Arrays;
import java.util.Scanner;


public class ac8600_prob10 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int cases = in.nextInt();
		
		int[][] table = new int[2][256];
		
		int n = 10000000;
		
		boolean[] primes = new boolean[n+1];
		Arrays.fill(primes, true);
		primes[0] = false;
		primes[1] = false;
		for(int i = 2; i < Math.sqrt(n) + 1; i++){
			for(int j = 2*i; j <= n; j+=i){
				if(primes[i]) primes[j] = false;
			}
		}
		
		int cur = 0;
		for(int i = 0; i <= n; i++){
			if(primes[i]){
				table[0][cur] = i;
				cur++;
			}
			if(cur > 255) break;
		}
		
	//	System.err.println(table[0][255]);
		table[1][0] = 2;
		for(int i = 1; i < 256; i++){
			table[1][i] = table[0][i] + table[1][i-1];
		}
		
		for(int i = 0; i < cases; i++){
			int num = in.nextInt();
			System.out.println(table[1][num]);
		}
	}
/*
3
0
5
7

 */
}

