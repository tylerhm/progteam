/*
9
0
1
2
3
4
5
6
7
255
 */

import java.util.*;

public class ac8591_prob10 {

	public static void main(String[] args) {
		new ac8591_prob10();
	}
	
	public ac8591_prob10() {
		Scanner sc = new Scanner(System.in);
		
		boolean[] p = notPrimeList(5000);
		
		ArrayList<Long> primes = new ArrayList<Long>();
		for(long i = 0; i < p.length; i++){
			if(!p[(int) i]){
				primes.add(i);
			}
		}

		long[] s = new long[300];
		s[0] = 2;
		
		for(int i = 1; i < 300; i++){
				s[i] += s[i-1] + primes.get(i);
		}
		
		int t = sc.nextInt();
		for(int tc = 0; tc < t; tc++){
			int n = sc.nextInt();
			System.out.println(s[n]);
		}
		
		sc.close();
	}
	
	public boolean[] notPrimeList(long size) {
		boolean[] notPrime = new boolean[(int) (size + 1)];
		notPrime[0] = notPrime[1] = true;
		
		for(long i = 2; i * i <= size; i++){
			if(notPrime[(int) i]){
				continue;
			}
			
			for(long j = i * i; j <= size; j += i){
				notPrime[(int) j] = true;
			}
		}
		
		return notPrime;
	}
}

