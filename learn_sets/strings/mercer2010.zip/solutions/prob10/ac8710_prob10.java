//Ryan Kelsey
import java.util.Arrays;
import java.util.Scanner;

public class ac8710_prob10 {
	public static void main(String[] args) {
		boolean[] isPrime = new boolean[10000];
		Arrays.fill(isPrime, true);
		for(int i = 2; i < 10000; i++)
			if(isPrime[i])
				for(int j = i + i; j < 10000; j += i)
					isPrime[j] = false;
		
		int[] cumFreq = new int[256];
		int c = 0;
		cumFreq[c++] = 2;
		for(int i = 3; i < 10000 && c < 256; i++)
			if(isPrime[i])
				cumFreq[c] = cumFreq[c++ - 1] + i;
		
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		
		for(int z = 1; z <= runs; z++)
			System.out.println(cumFreq[scan.nextInt()]);
		scan.close();
	}
}
