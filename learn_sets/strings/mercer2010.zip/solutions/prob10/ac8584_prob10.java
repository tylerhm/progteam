import java.io.*;
import java.util.*;

public class ac8584_prob10 {
	public static void main(String[] args) throws IOException {
		int[] primes = new int[256];
		primes[0] = 2;
		int done = 1;
		int p = 3;
		while(done < 256) {
			boolean prime = true;
			for(int i = 0; prime && primes[i]*primes[i] <= p 
					             && i < done; i++)
				if(p%primes[i]==0)
					prime = false;
			if(prime)
				primes[done++] = p;
			p+=2;
		}
		
		long[] sums = new long[256];
		sums[0] = 2l;
		for(int i = 1; i < 256; i++)
			sums[i] = sums[i-1]+primes[i];
		
		Scanner in = new Scanner(System.in);
		int tc = in.nextInt();
		for(int cc = 0; cc < tc; cc++) {
			System.out.println(sums[in.nextInt()]);
		}
	}
}

