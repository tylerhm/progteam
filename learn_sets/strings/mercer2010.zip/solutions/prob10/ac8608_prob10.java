import java.util.Arrays;
import java.util.Scanner;

public class ac8608_prob10 {

	final public static int MAX = 999999;

	public static void main(String[] args) {

		boolean[] isPrime = new boolean[MAX];

		
		Arrays.fill(isPrime, true);
		isPrime[0] = false;
		isPrime[1] = false;

		for (int i = 2; i < Math.sqrt(MAX) + 1; i++)
			if (isPrime[i])
				for (int j = 2 * i; j < MAX; j += i)
					isPrime[j] = false;
		// done generating primes
		
		// Count primes.
		int numprimes = 0;
		for (int i = 0; i < MAX; i++)
			if (isPrime[i])
				numprimes++;

		// copy primes over
		int[] primelist = new int[numprimes];
		int j = 0;
		for (int i = 0; i < MAX; i++)
			if (isPrime[i])
				primelist[j++] = i;

		int[] primesum = new int[numprimes];
		j = 0;
		for (int i = 0; i < MAX; i++) {
			if (isPrime[i]) {
				primesum[j] = primelist[j];
				for (int k = j-1; k > -1; k--)
					primesum[j] += primelist[k];
				j++;
			}
		}

		Scanner in = new Scanner(System.in);

		int times = in.nextInt();

		for (int i = 0; i < times; i++) {
			System.out.println(primesum[in.nextInt()]);
		}

	}

}

