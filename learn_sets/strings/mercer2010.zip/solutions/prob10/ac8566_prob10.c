#include <stdio.h>

int main()
{
    int eratosthenes[10000], sum[256], i, j, c;
    for (i = 0; i < 10000; ++i) eratosthenes[i] = 1;
    for (i = 2; i < 100; ++i) for (j = i * 2; j < 10000; j += i) eratosthenes[j] = 0;
    eratosthenes[0] = eratosthenes[1] = 0;
    for (i = j = sum[0] = 0; i < 10000; ++i) if (eratosthenes[i]) sum[j++] += i;
    for (i = 1; i < 256; ++i) sum[i] += sum[i - 1];
    scanf("%d", &c);
    while (c--)
    {
        scanf("%d", &i);
        printf("%d%n", sum[i]);
    }
    return 0;
}

