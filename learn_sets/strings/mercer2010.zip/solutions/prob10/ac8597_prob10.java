import java.util.Arrays;
import java.util.Scanner;

public class ac8597_prob10 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		boolean[] isPrime = new boolean[10000];
		Arrays.fill(isPrime, true);
		for(int i = 2; i < 10000; i++) {
			for(int j = i * i; j < 10000; j += i) {
				isPrime[j] = false;
			}
		}
		
		int[] cumFreq = new int[256];
		cumFreq[0] = 2;
		
		
		
		
		int c = 1;
		for(int i = 3; i < 10000 && c < 256; i++) {
			if(isPrime[i]) {
				cumFreq[c] = cumFreq[c - 1] + i;
				c++;
			}
		}

		int runs = scan.nextInt();
		for(int z = 1; z <= runs; z++) {
			int n = scan.nextInt();
			System.out.println(cumFreq[n]);
		}
		scan.close();
	}
}

