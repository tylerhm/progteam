import java.util.*;

public class ac8614_prob10 {

	boolean[] sieve;
	int[] primes;
	int[] primeSum;
	ac8614_prob10()
	{
		Scanner input = new Scanner(System.in);
		sieve = new boolean[66000];
		sieve[0] = true;
		sieve[1] = true;
		int tc = input.nextInt();
		
		primes = new int[256];
		primeSum = new int[256];
		primeSum[0] = 2;
		primes[0] = 2;
		getSieve();
		
		for(int c = 0; c < tc; c++)
		{
			int n = input.nextInt();
			
			System.out.println(primeSum[n]);
			
		}
	}
	
	void getSieve()
	{
		int count = 1;
		
		for(int i = 2; i < 66000; i++)
		{
			if(sieve[i] == false && count < 256)
			{
				if(i != 2)
				{
					primes[count] = i;
					primeSum[count] = primeSum[count-1] + i;
					count++;
				}
			
				
			}
			for(int j = i; j < 66000; j += i)
			{
				sieve[j] = true;
			}
		}
		
	}
	
	public static void main(String[] args)
	{
		ac8614_prob10 p = new ac8614_prob10();
	}
}

