#include <stdio.h>
#include <stdlib.h>

typedef struct starbucks
{
    char *name;
    int distance;
    float pass;
} starbucks;

void sort(starbucks [3000], int);
void swap(starbucks [3000], int, int);
int StrCmp(char *, char *);

int main()
{
    char *str = NULL, *buf = NULL, temp;
    int size = 0, i, num = 0;
    starbucks star[3000];
    do
    {
        temp = getc(stdin);
        if (temp != '%n' && temp != ',')
        {
            if (buf) free(buf);
            buf = malloc(sizeof(char) * (++size + 1));
            for (i = 0; i < size - 1; ++i) buf[i] = str[i];
            buf[i] = temp;
            buf[i + 1] = '\0';
            if (str) free(str);
            str = malloc(sizeof(char) * (size + 1));
            for (i = 0; i < size; ++i) str[i] = buf[i];
            str[i] = '\0';
        }
        else
        {
            if (StrCmp(str, "END"))
            {
                sort(star, num);
                //for (i = 0; i < num; ++i) printf("%s, %d, %f%n", star[i].name, star[i].distance, star[i].pass);
                for (i = 0; i < num; ++i) if (star[i].pass <= 2.0) printf("%s, Exit %d%n", star[i].name, star[i].distance);
                return 0;
            }
            else
            {
                star[num].name = malloc(sizeof(char) * (size + 1));
                for (i = 0; i < size; ++i) star[num].name[i] = str[i];
                star[num].name[i] = '\0';
                size = 0;
                scanf("%d,%f", &star[num].distance, &star[num].pass);
                getc(stdin);
                ++num;
            }
        }
    } while (1);
}

void sort(starbucks n[3000], int size)
{
    int i, j;
    for (i = 1; i < size; ++i) for (j = i; j > 0; --j) if (n[j].distance < n[j - 1].distance || (n[j].distance == n[j - 1].distance && n[j].pass < n[j - 1].pass)) swap(n, j, j - 1);
}

void swap(starbucks n[3000], int i, int j)
{
    starbucks temp = n[i];
    n[i] = n[j];
    n[j] = temp;
}

int StrCmp(char *a, char *b)
{
    int i = 0;
    while (a[i] == b[i]) if (a[i++] == '\0') return 1;
    return 0;
}

