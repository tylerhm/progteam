import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.TreeSet;


public class ac8586_prob4 {
	static class Starbucks implements Comparable<Starbucks> {
		String name;
		int exit;
		double dist;
		
		@Override
		public String toString() {
			return name + ", Exit " + exit;
		}
		
		public int compareTo(Starbucks s) {
			int compare = Integer.compare(exit, s.exit);
			if(compare == 0)
				return Double.compare(dist, s.dist);
			return compare;
		}
	}
	public static void main(String[] args) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		Set<Starbucks> starbucks = new TreeSet<Starbucks>();
		while(true) {
			String line = reader.readLine().trim();
			if(line == null || line.equals("END"))
				break;
			
			String[] parts = line.split("\\,");
			Starbucks s = new Starbucks();
			s.name = parts[0];
			s.exit = Integer.parseInt(parts[1]);
			s.dist = Double.parseDouble(parts[2]);
			if(s.dist <= 2.0)
				starbucks.add(s);
		}
		
		for(Starbucks s : starbucks)
			System.out.println(s);
	}
}

