import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class ac8607_prob4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String line = "";
		ArrayList<StarBucks> bucks = new ArrayList<StarBucks>();
		while(!(line = scan.nextLine()).equals("END")){
			if(Double.parseDouble(line.split(",")[2]) <= 2)
				bucks.add(new StarBucks(line.split(",")[0], Integer.parseInt(line.split(",")[1]), Double.parseDouble(line.split(",")[2])));
		}
		Collections.sort(bucks);
		for(int i = 0; i < bucks.size(); i++){
			System.out.println(bucks.get(i));
		}
	}
}

class StarBucks implements Comparable<StarBucks>{
	String name;
	int exit;
	double dist;
	public StarBucks(String n, int e, double d){
		name = n;
		exit = e;
		dist = d;
	}
	public String toString(){
		return name + ", Exit " + exit;
	}
	@Override
	public int compareTo(StarBucks o) {
		if(exit == o.exit){
			return (int) (dist*100000 - o.dist*100000);
		}
		return exit-o.exit;
	}
}
