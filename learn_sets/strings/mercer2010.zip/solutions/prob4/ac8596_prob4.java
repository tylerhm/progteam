import java.util.*;

public class ac8596_prob4 {

	
	ac8596_prob4()
	{
		Scanner input = new Scanner(System.in);
		
		ArrayList<Exit> list = new ArrayList<Exit>();
		while(true)
		{
			String line = input.nextLine();
			if(line.equals("END"))
				break;
			StringTokenizer tok = new StringTokenizer(line, ",");
			
			Exit e = new Exit();
			
			e.name = tok.nextToken().toString();
			e.exit = Integer.parseInt(tok.nextToken().toString());
			e.distance = Double.parseDouble(tok.nextToken().toString());
			
			if(e.distance <= 2.0)
			{
				list.add(e);
			}
			
			
		
		
		}
		
		Collections.sort(list);
		
		for(int i = 0; i < list.size(); i++)
		{
			System.out.println(list.get(i).toString());
		}
		
	}
	
	public static void main(String[] args)
	{
		ac8596_prob4 p = new ac8596_prob4();
	}
}

class Exit implements Comparable<Exit>
{
	
	String name;
	int exit;
	double distance;
	
	Exit()
	{
	
	}

	public int compareTo(Exit other) {
		
		
		if(this.exit < other.exit)
		{
			return -1;
		}
		else if(this.exit > other.exit)
		{
			return 1;
		}
		else
		{
			if(this.distance < other.distance)
				return -1;
			else
				return 1;
		}
		
	}
	
	public String toString()
	{
		return name + ", Exit " + exit;
	}
}
