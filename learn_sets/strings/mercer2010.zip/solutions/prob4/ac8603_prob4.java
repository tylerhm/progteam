import java.awt.LinearGradientPaint;
import java.awt.Point;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*

Epps,40,1.5
Tiger,25,4.2
Main,25,1.0
Your,25,50
Green,150,4
END
 */
public class ac8603_prob4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		ArrayList<Bucks> list = new ArrayList<Bucks> ();
		while(true) {
		String string = scan.nextLine();
			if(string.equals("END")) {
				break;
			}
			
			String [] array = string.split(",");
			if(Double.parseDouble(array[2]) <= 2.0) {
				list.add(new Bucks(array[0], Integer.parseInt(array[1]), Double.parseDouble(array[2])));
			}
		}
		Collections.sort(list);
		
		for(Bucks bucks : list) {
			System.out.println(bucks.nameString + ", Exit " + bucks.exit);
		}
	}	


}
class Bucks implements Comparable<Bucks>{
	String nameString;
	int exit;
	double distance;
	
	public Bucks(String name, int e, double d) {
		nameString = name;
		exit = e;
		distance = d;
	}

	@Override
	public int compareTo(Bucks o) {
		// TODO Auto-generated method stub
		if(exit == o.exit) {
			return (int) (distance*10000 - o.distance*10000);
		}
		return exit - o.exit;
	}
}
