import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class sb implements Comparable<sb>{
	String name;
	int exit;
	double d;
	boolean t = true;
	public sb(String s) {
		name = s.substring(0, s.indexOf(','));
		s = s.substring(s.indexOf(',')+1);
		exit = Integer.parseInt(s.substring(0, s.indexOf(',')));
		s = s.substring(s.indexOf(',')+1);
		d = Double.parseDouble(s);
		if(d > 2){
			t = false;
		}
	}
	public int compareTo(sb arg0) {
		if(this.exit == arg0.exit){
			if(this.d > arg0.d){
				return 1;
			}
			else
				return -1;
		}
		return this.exit - arg0.exit;
	}
	public String toString() {
		return name + ", Exit " + exit;
	}
}
public class ac8619_prob4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		ArrayList<sb> exits = new ArrayList<sb>();
 		while(true) {
			String s =  in.nextLine();
			if(s.equals("END"))break;
			sb temp = new sb(s);
			if(temp.t)
				exits.add(temp);
		}
 		Collections.sort(exits);
 		for (sb sb : exits) {
			System.out.println(sb);
		}

	}

}

