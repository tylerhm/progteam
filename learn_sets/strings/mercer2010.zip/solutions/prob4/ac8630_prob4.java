/*
Epps Bridge Road,40,1.5
Tiger Blvd,25,4.2
Main Street,25,1.0
Your Street,25,50
Green Street,150,4
END

Hi,0,0.1
Bob,500,100
Bill,500,1.8
B,500,1.7
END
 */

import java.util.*;

public class ac8630_prob4 {

	public static void main(String[] args) {
		new ac8630_prob4();
	}
	
	public ac8630_prob4() {
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Exit> exits = new ArrayList<Exit>();
		while(true){
			String input = sc.nextLine();
			if(input.compareTo("END") == 0){
				break;
			}
			
			String[] info = input.split(",");
			if(Double.parseDouble(info[2]) > 2.0){
				continue;
			}
			
			exits.add(new Exit(info[0], Integer.parseInt(info[1]), Double.parseDouble(info[2])));
		}
		
		Collections.sort(exits);
		//System.out.println("Sorted: " + exits);
		
		for(int i = 0; i < exits.size(); i++){
			if(exits.get(i).starbucks <= 2.0){
				System.out.println(exits.get(i));
			}
		}
		
		sc.close();
	}
	
	public class Exit implements Comparable<Exit> {
		String name;
		int distance;
		double starbucks;
		
		public Exit(String name, int distance, double starbucks) {
			this.name = name;
			this.distance = distance;
			this.starbucks = starbucks;
		}
		
		public int compareTo(Exit other) {
			if(distance != other.distance){
				return Integer.compare(distance, other.distance);
			}
			else{
				if(starbucks < other.starbucks){
					return -1;
				}
				return 1;
			}
		}
		
		public String toString() {
			return name + ", Exit " + distance; 
		}
	}
}

