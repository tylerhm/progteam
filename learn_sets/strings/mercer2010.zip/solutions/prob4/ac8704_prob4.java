//Ryan Kelsey
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ac8704_prob4 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String line = scan.nextLine();
		List<Exit> list = new ArrayList<Exit>();
		
		while(!line.trim().equals("END")) {
			String[] parts = line.split(",");
			if(Double.parseDouble(parts[2]) <= 2) {
				list.add(new Exit(parts[0], Integer.parseInt(parts[1]), Double.parseDouble(parts[2])));
			}
			line = scan.nextLine();
		}
		
		Collections.sort(list);
		for(Exit e : list)
			System.out.println(e);
		scan.close();
	}
}

class Exit implements Comparable<Exit> {
	public String str;
	public int e;
	public double dist;
	
	public Exit(String str, int e, double dist) {
		this.str = str;
		this.e = e;
		this.dist = dist;
	}
	
	public String toString() {
		return String.format("%s, Exit %d", this.str, this.e);
	}
	
	public int compareTo(Exit other) {
		if(this.e == other.e)
			return Double.compare(this.dist, other.dist);
		return Integer.compare(this.e, other.e);
	}
}
