import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.StringTokenizer;


public class ac8625_prob4 {
	
	static class starbux{
		String name;
		int exitdist;
		int dist;
		public starbux(String n, int e, int d){
			name = n;
			exitdist = e;
			dist = d;
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		String line = in.nextLine();
		ArrayList<starbux> stops = new ArrayList<starbux>();
		boolean done = false;
		while(!line.equals("END") && !done){
			StringTokenizer strk = new StringTokenizer(line, ",");
			stops.add(new starbux(strk.nextToken(), Integer.parseInt(strk.nextToken()), (int)(Double.parseDouble(strk.nextToken())*100+.001)));
			line = in.nextLine();
		}
		
		Collections.sort(stops, new Comparator<starbux>(){

			public int compare(starbux arg0, starbux arg1) {
				return arg0.exitdist < arg1.exitdist ? -1 : arg0.exitdist > arg1.exitdist ? 1 : arg0.dist < arg1.dist ? -1 : 1;
			}
			
		});
		
		for(int i = 0; i < stops.size(); i++){
			if(stops.get(i).dist <= 200){
				System.out.printf("%s, Exit %d%n", stops.get(i).name, stops.get(i).exitdist);
			}
		}
	}
	/*
Epps Bridge Road,40,1.5
Tiger Blvd,25,6.2
Main Street,25,1.0
Your Street,25,50
Green Street,150,4
My Street,25,2.0
Their Street,25,1.01
Street,300,1.0
nothing,30,2.01
nothing2,30,2.00
DEADEND,1,1
END

	 */

}

