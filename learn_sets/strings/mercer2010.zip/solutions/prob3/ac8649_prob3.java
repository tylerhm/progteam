import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class ac8649_prob3 {
	
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		ArrayList<String> par = new ArrayList<String>();
		while(in.hasNext()) {
			String s = in.next();
			s = s.toLowerCase();
			char[] ch = s.toCharArray();
			s = "";
			for (int i = 0; i < ch.length; i++) {
				if(ch[i] >= 'a' && ch[i] <= 'z')
					s += ch[i];
			}
			par.add(s);
		}
		Collections.sort(par);
		ArrayList<String> words = new ArrayList<String>();
		String temp = par.get(0);
		int count = 1;
		int max = 0;
		for (int i = 1; i < par.size(); i++) {
			String cur = par.get(i);
			if(cur.equals(temp)){
				count++;
				if(count == max){
					words.add(cur);
				}
				if(count > max){
					max = count;
					words.clear();
					words.add(cur);
				}
			} else 
				count = 1;
			temp = cur;
		}
		Collections.sort(words);
		System.out.print("My median=[");
		int l = par.size();
		if(l % 2 ==0){
			System.out.print(par.get((l/2)-1) + ",");
			System.out.println(par.get((l/2)) + "]");
		} else {
			System.out.println(par.get(l/2) + "]");
		}
		if(max == 0){words = par;max++;}
		System.out.print("My mode=[");
		for (int j = 0; j < words.size(); j++) {
			if(j == words.size()-1)
				System.out.println(words.get(j)+"(" + max + ")]");
			else 
				System.out.print(words.get(j)+"(" + max + "),");
		}
	}

}
/*
When April with his sweet showers has
pierced the drought of MArch to the root,
and bathed every vein in such moisture
as has power to bring forth the flower

*/
