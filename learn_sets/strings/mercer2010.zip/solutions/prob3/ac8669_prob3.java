import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/*
When April with his sweet showers has
pierced the drought of March to the root,
and bathed every vein in such moisture
as has power to bring forth the flower

123abc,,, hello HELLO Hello HELLo 123456789-----he,,..llo
 */
public class ac8669_prob3 {
	
	static class mode{
		int freq = 1;
		String word;
		public mode( String w){
			word = w;
		}
	}
	
	public static String removeother(String w){
		String ret = "";
		for(int i = 0; i < w.length(); i++){
			char c = w.charAt(i);
			int f = (int)c;
			if(f < 97) f+=32;
			if(f >= 97 && f <=122) ret+=(char)f;
		}
		return ret;
	}

	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		//Scanner in = new Scanner(new File("som.in"));
		ArrayList<String> words = new ArrayList<String>();
		
		while(in.hasNext()){
			String w = in.next();
			String done = removeother(w);
			if(!done.equals(""))
				words.add(done);
		}
		
		//median section---------------------
		int len = words.size();
		Collections.sort(words, new Comparator<String>(){

			public int compare(String arg0, String arg1) {
				return arg0.compareTo(arg1);
			}
			
		});
		
		
		System.out.print("My median=[");
		if(len % 2 == 0 && len >0){
			
			int i = len/2-1;
			int j = len/2;
			String o = words.get(i);
			String t = words.get(j);
			int comp = words.get(i).compareTo(words.get(j));
			
			if(comp < 0){
				System.out.print(o+","+t+"]");
			}
			else System.out.print(t+","+o+"]");
		}
		else if(len >= 1)System.out.print(words.get(len/2)+"]");
		System.out.println();
		
		//mode section----------------------------
		ArrayList<mode> modes = new ArrayList<mode>();
		for(String s : words){
			boolean placed = false;
			for(mode t : modes){
				if(s.equals(t.word)){
					t.freq++;
					break;
				}
			}
			if(!placed) modes.add(new mode(s));
		}
		
		Collections.sort(modes, new Comparator<mode>(){

			public int compare(mode arg0, mode arg1) {
				return Integer.compare(arg0.freq, arg1.freq);
			}
			
		});
		
		int max = modes.get(modes.size()-1).freq;
		ArrayList<mode> complete = new ArrayList<mode>();
		complete.add(modes.get(modes.size()-1));
		int cur = modes.size()-1;
		while(cur >=1 && max == modes.get(cur-1).freq){
			complete.add(modes.get(cur-1));
			cur--;
		}
		
		Collections.sort(complete, new Comparator<mode>(){

			public int compare(mode arg0, mode arg1) {
				return arg0.word.compareTo(arg1.word);
			}
			
		});
		
		System.out.print("My mode=[");
		for(int i = 0; i < complete.size()-1; i++){
			System.out.print(complete.get(i).word+"("+complete.get(i).freq+")"+",");
		}
		System.out.print(complete.get(complete.size()-1).word +"("+complete.get(complete.size()-1).freq+")"+ "]%n");
	}

}

