import java.util.*;


public class ac8602_prob3 {
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		
		List<String> words = new ArrayList<String>();
		final Map<String, Integer> count = new HashMap<String, Integer>();
		while(true) {
			try {
				String word = scanner.next().toLowerCase().replaceAll("[^a-z]", "");
				words.add(word);
				Integer i = count.get(word);
				if(i == null)
					i = 0;
				count.put(word, ++i);
			} catch(Exception e) {
				break;
			}
		}
		Collections.sort(words);
		
		System.out.print("My median=[");
		if(words.size() > 0) {
			if(words.size() % 2 == 0) {
				System.out.print(words.get(words.size() / 2 - 1));
				System.out.print(',');
			}
			System.out.print(words.get(words.size() / 2));
		}
		System.out.println(']');
		
		Collections.sort(words, new Comparator<String>() {
			public int compare(String a, String b) {
				int compare = -count.get(a).compareTo(count.get(b));
				if(compare == 0)
					return a.compareTo(b);
				return compare;
			}
		});
		
		int size = -1;
		Set<String> mode = new HashSet<String>();
		for(String word : words) {
			int freq = count.get(word);
			if(size == -1)
				size = freq;
			else if(freq < size)
				break;
			
			mode.add(word);
		}
		
		System.out.print("My mode=[");
		boolean first = true;
		for(String word : mode) {
			if(!first)
				System.out.print(',');
			else
				first = false;
			
			System.out.print(word);
			System.out.print('(');
			System.out.print(size);
			System.out.print(')');
		}
		System.out.println(']');
	}
}

