import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ac8609_prob3 {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		HashMap<String, Integer> count = new HashMap<String, Integer>();
		ArrayList<String> words = new ArrayList<String>();
		ArrayList<String> mode = new ArrayList<String>();
		StringBuilder add;
		String temp;
		int i, most = 0;
		
		//Read in words
		
		while(in.hasNext()){
			temp = in.next();
			add = new StringBuilder();
			
			for(i = 0; i < temp.length(); i++)
				if(Character.isLetter(temp.charAt(i)))
					add.append(Character.toLowerCase(temp.charAt(i)));
			
			words.add(new String(add));
		}
		Collections.sort(words);
		
		
		//Find median
		System.out.print("My median=[" + words.get(words.size() / 2 - 1));
		if(words.size() > 2 && words.size() % 2 == 0)
			System.out.print("," + words.get(words.size() / 2));
		System.out.println("]");
		
		
		//Find mode
		System.out.print("My mode=[");
		for(String curWord : words){
			if(count.containsKey(curWord))
				count.put(curWord, count.get(curWord) + 1);
			else
				count.put(curWord, 1);
			
			if(most == count.get(curWord))
				mode.add(curWord);
			
			else if(most < count.get(curWord)){
				most = count.get(curWord);
				mode.clear();
				mode.add(curWord);
			}
		}
		System.out.print(mode.get(0) + "(" + most + ")");
		for(i = 1; i < mode.size(); i++)
			System.out.print("," + mode.get(i) + "(" + most + ")");
		System.out.println("]");
		
		in.close();
	}

}

