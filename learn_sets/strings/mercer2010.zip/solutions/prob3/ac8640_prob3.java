/*
When April with his sweet showers has
pierced the drought of March to the root,
and bathed every vein in such moisture
as has power to bring forth the flower

When April with his sweet showers has pierced the drought of March to the root, and bathed every vein in such moisture as has power to bring forth the flower
 */

import java.util.*;

public class ac8640_prob3 {
	
	public static void main(String[] args) {
		new ac8640_prob3();
	}
	
	public ac8640_prob3() {
		Scanner sc = new Scanner(System.in);
		
		ArrayList<String> words = new ArrayList<String>();
		while(sc.hasNext()){
			String[] input = sc.nextLine().split(" ");
			
			for(int i = 0; i < input.length; i++){
				String temp = input[i].toLowerCase();
				words.add(temp.replaceAll("[^a-z]", ""));
			}
		}
		
		Collections.sort(words);
		
		int max = 0;
		TreeSet<String> ans = new TreeSet<String>();

		TreeMap<String, Integer> map = new TreeMap<String, Integer>();
		for(int i = 0; i < words.size(); i++){
			String word = words.get(i);
			
			if(!map.containsKey(word)){
				map.put(word, 1);
			}
			else{
				int freq = map.get(word) + 1;
				map.put(word, freq);
				
				if(max == freq){
					ans.add(word);
				}
				else if(max < freq){
					max = freq;
					ans.clear();
					ans.add(word);
				}
			}
		}
		
		int total = words.size();
		if(total % 2 != 0){
			System.out.println("My median=[" + words.get(total / 2) + "]");
		}
		else{
			System.out.println("My median=[" + words.get((total / 2) - 1) + "," + words.get(total / 2) + "]");
		}
		
		String output = "My mode=[";
		for(String w : ans){
			output += w + "(" + max + "),";
		}
		System.out.println(output.substring(0, output.length() - 1) + "]");
		
		sc.close();
	}
}

