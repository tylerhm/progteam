import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class ac8626_prob3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<String> words = new ArrayList<String>();
		while(scan.hasNext()){
			String word = scan.next().toLowerCase().replaceAll("[\\W]|_", "");;

			//if(word.equals("gg")) break;

			words.add(word);
		}
		Collections.sort(words);
		if(words.size()%2 == 1){
			System.out.println("My median=["+words.get(words.size()/2)+"]");
		}else {
			System.out.println("My median=["+words.get(words.size()/2-1)+","+words.get(words.size()/2)+"]");
		}

		ArrayList<Word> w = new ArrayList<Word>();
		for(int i =0; i < words.size(); i++){
			boolean added = false;
			for(int j =0; j < w.size(); j++){
				if(w.get(j).word.equals(words.get(i))){
					added = true;
					w.get(j).freq++;
					break;
				}
			}
			if(!added)
				w.add(new Word(words.get(i)));
		}

		Collections.sort(w);
		if(w.get(0).freq == w.get(1).freq){
			System.out.print("My mode=[");
			ArrayList<Word> modes = new ArrayList<Word>();
			for(Word ww : w){
				if(ww.freq != w.get(0).freq)
					break;

				modes.add(ww);
			}
			Collections.sort(modes);
			for(int i =0; i < modes.size(); i++){
				Word ww = modes.get(i);
				if(i < modes.size()-1)
					System.out.print(ww.word+"("+ww.freq+"),");
				else
					System.out.print(ww.word+"("+ww.freq+")");
			}
			System.out.println("]");

		}else {
			System.out.println("My mode=["+w.get(0).word+"("+w.get(0).freq+")]");
		}
	}

}

class Word implements Comparable<Word>{
	String word;
	int freq;
	public Word(String w) {
		word = w;
		freq = 1;
	}
	@Override
	public int compareTo(Word o) {
		if(o.freq == freq)
			return word.compareTo(o.word);
		return o.freq-freq;
	}
}

