//Ryan Kelsey
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ac8703_prob3 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		List<String> median = new ArrayList<String>();
		List<String> mode = new ArrayList<String>();
		
		while(scan.hasNext()) {
			StringBuilder str = new StringBuilder(scan.next().toLowerCase());
			for(int i = 0; i < str.length(); i++) {
				if(!Character.isAlphabetic(str.charAt(i))) {
					str.deleteCharAt(i);
					i--;
				}
			}
			median.add(str.toString());
		}
		
		Collections.sort(median);
		if(median.size() % 2 == 0)
			System.out.printf("My median=[%s,%s]%n", median.get(median.size() / 2 - 1), median.get(median.size() / 2));
		else
			System.out.printf("My median=[%s]%n", median.get(median.size() / 2));
		
		String cur = "";
		int max = 0, curr = 0;
		for(int i = 0; i < median.size(); i++) {
			if(!median.get(i).equals(cur)) {
				cur = median.get(i);
				curr = 1;
				if(curr > max) {
					max = curr;
					mode.clear();
					mode.add(cur);
				} else if(curr == max) {
					mode.add(cur);
				}
			} else {
				curr++;
				if(curr > max) {
					max = curr;
					mode.clear();
					mode.add(cur);
				} else if(curr == max) {
					mode.add(cur);
				}
			}
		}
		
		System.out.print("My mode=[");
		for(int i = 0; i < mode.size() - 1; i++) {
			System.out.printf("%s(%d),", mode.get(i), max);
		}
		System.out.printf("%s(%d)]%n", mode.get(mode.size() - 1), max);
		scan.close();
	}
}
