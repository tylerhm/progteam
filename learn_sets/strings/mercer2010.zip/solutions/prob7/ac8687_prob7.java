import java.util.*;

public class ac8687_prob7
{
	public static void main(String[] arg)
	{
		Scanner in = new Scanner(System.in);
		int cases = in.nextInt();
		for(int cc = 1; cc <= cases; cc++)
		{
			String temp = in.next();
			long[][] memo = new long[temp.length()+1][temp.length()+1];
			for(int i = 0; i < memo.length; i++)
				Arrays.fill(memo[i], -1);
			//boolean flag = false;
			for(int i = 0; i < temp.length(); i++)
			{
				if(temp.charAt(i) == '1')
					memo[i][i] = 0;
				else
				{
					memo[i][i] = 1;
					//flag = true;
				}
			}
			//if(!flag && temp.length() > 1)
			//	System.out.println(1);
			//else
				System.out.println(solve(temp, 0 , temp.length()-1, memo));
		}
	}
	public static long solve(String tree, int start, int end, long[][] memo)
	{
		if(start > end)
			return 1;
		if(memo[start][end] != -1)
			return memo[start][end];
		long answer = 0;
		for(int i = start; i <= end; i++)
		{
			if(tree.charAt(i) == '0')
				continue;
			long left = solve(tree, start, i-1, memo) % 1_000_001;
			long right = solve(tree, i+1, end, memo) % 1_000_001;
			answer += ((left%1_000_001)*(right%1_000_001))%1_000_001;
		}
		
		return memo[start][end] = answer % 1_000_001;
	}
}
