import java.util.*;
import java.math.*;
public class ac8720_prob7 {
	
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		HashMap<String, BigInteger> dp = new HashMap<String, BigInteger>();
		int cases = Integer.parseInt(in.nextLine());
		for (int i = 0; i < cases; ++i) System.out.printf("%s%n", Solve(dp, in.nextLine()).mod(new BigInteger("1000001")));
		in.close();
	}
	
	public static BigInteger Solve(HashMap<String, BigInteger> dp, String str) {
		BigInteger num = new BigInteger("0");
		if (dp.containsKey(str)) return dp.get(str);
		if (str.isEmpty() || (str.length() == 1 && str.charAt(0) == '0')) return new BigInteger("1");
		else if ((str.length() == 1 && str.charAt(0) == '1') || !str.contains("1")) return new BigInteger("0");
		for (int i = 0; i < str.length(); ++i) if (str.charAt(i) == '1') num = num.add(Solve(dp, str.substring(0, i)).multiply(Solve(dp, str.substring(i + 1, str.length()))));
		dp.put(str, num);
		return dp.get(str);
	}
}

