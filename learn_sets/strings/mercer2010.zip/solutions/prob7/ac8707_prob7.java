//Ryan Kelsey
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ac8707_prob7 {
	public static final long MOD = 1_000_001L;
	public static Map<String, Long> memo;
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		
		for(int z = 1; z <= runs; z++) {
			String tree = scan.next();
			memo = new HashMap<String, Long>();
			System.out.println(go(tree));
		}
		scan.close();
	}
	
	public static long go(String subtree) {
		if(subtree.equals("") || subtree.equals("0"))
			return 1L;
		else if(subtree.equals("1"))
			return 0L;
		else if(memo.containsKey(subtree))
			return memo.get(subtree);
		
		long res = 0L;
		for(int i = 0; i < subtree.length(); i++) {
			if(subtree.charAt(i) == '1') {
				res += go(subtree.substring(0, i)) * go(subtree.substring(i + 1));
				res %= MOD;
			}
		}
		memo.put(subtree, res);
		return res;
	}
}
