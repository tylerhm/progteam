import java.util.*;


public class ac8690_prob7 {
	static Map<String, Long> memo;
	//static int depth = 0;
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int sets = scanner.nextInt();
		for(int set = 1; set <= sets; set++) {
			String tree = scanner.next();
			memo = new HashMap<String, Long>();
			memo.put("", 1L);
			memo.put("0", 1L);
			memo.put("1", 0L);
			
			System.out.println(count(tree));
		}
	}
	
	private static long count(String tree) {
		//for(int i = 0; i < depth; i++)
		//	System.out.print(' ');
		//System.out.print(tree);
		Long stored = memo.get(tree);
		if(stored != null) {
			//System.out.println(" = " + stored);
			return stored;
		}
		//System.out.println();
		//depth++;
		
		long acc = 0;
		for(int i = 0; i < tree.length(); i++) {
			if(tree.charAt(i) != '1')
				continue;
			
			//for(int j = 0; j < depth; j++)
			//	System.out.print(' ');
			//System.out.println("Next (" + i + "):");
			long res = count(tree.substring(0, i)) * count(tree.substring(i + 1, tree.length()));
			acc = (acc + (res % 1000001)) % 1000001;
		}
		//depth--;
		memo.put(tree, acc);
		//for(int i = 0; i < depth; i++)
		//	System.out.print(' ');
		//System.out.println(" -> " + acc);
		return acc;
	}
}

