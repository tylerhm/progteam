import java.util.Scanner;
/*
3
2
1 4 5
2 6
1
3 -7
0
 */

public class ac8564_prob1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int day = in.nextInt();
		
		for(int i = 1; i <= day; i++){
			int sum = 0;
			int trans = in.nextInt();
			for(int j = 0; j < trans; j++){
				int next = in.nextInt();
				int p = 0, q = 0;
				if(next == 1){
					p = in.nextInt();
					q = in.nextInt();
					sum += q*p;
				}
				else if(next == 2){
					p = in.nextInt();
					sum += p;
				}
				else if(next == 3){
					p = in.nextInt();
					sum += p;
				}
			}
			System.out.println("Day " + i + ": $" + sum + ".");
		}
	}

}

