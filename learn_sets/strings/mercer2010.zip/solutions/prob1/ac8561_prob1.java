import java.util.Scanner;


public class ac8561_prob1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		int runs = scan.nextInt();
		for(int i =0; i < runs; i++){
			int total = 0;
			int trans = scan.nextInt();
			for(int j =0; j < trans; j++) {
				int op = scan.nextInt();
				if(op == 1){
					total += scan.nextInt()*scan.nextInt();
				}else if(op == 2){
					total += scan.nextInt();
				}else {
					total += scan.nextInt();
				}
			}
			System.out.println("Day "+(i+1)+": $"+total+".");
		}
	}

}

