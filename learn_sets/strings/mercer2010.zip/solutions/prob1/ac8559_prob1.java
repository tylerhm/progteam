import java.util.Scanner;


public class ac8559_prob1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int num_days = in.nextInt();
		
		for (int i = 1; i <= num_days; i++) {
			int num_trans = in.nextInt();
			in.nextLine();
			int revenue = 0;
			for (int j = 0; j < num_trans; j++) {
				String line = in.nextLine();
				Scanner scanLine = new Scanner(line);
				scanLine.nextInt();
				
				int dollars = scanLine.nextInt();
				if (scanLine.hasNextInt()) {
					dollars *= scanLine.nextInt();
				}
				
				revenue += dollars;
			}
			System.out.println("Day " + i + ": $" + revenue + ".");
		}

	}

}

