#include <stdio.h>

int main()
{
    int i, days, trans, j, swi, a, b, rev;
    scanf("%d", &days);
    for (i = 0; i < days; ++i)
    {
        scanf("%d", &trans);
        for (j = rev = 0; j < trans; ++j)
        {
            scanf("%d", &swi);
            switch(swi)
            {
            case 1:
                scanf("%d %d", &a, &b);
                rev += a * b;
                break;
            default:
                scanf("%d", &a);
                rev += a;
            }
        }
        printf("Day %d: $%d.%n", i + 1, rev);
    }
    return 0;
}

