//Ryan Kelsey
import java.util.Scanner;

public class ac8701_prob1 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		
		for(int z = 1; z <= runs; z++) {
			int n = scan.nextInt();
			int sum = 0;
			for(int i = 0; i < n; i++) {
				int _case = scan.nextInt();
				if(_case == 1)
					sum += scan.nextInt() * scan.nextInt();
				else
					sum += scan.nextInt();
			}
			System.out.printf("Day %d: $%d.%n", z, sum);
		}
		scan.close();
	}
}
