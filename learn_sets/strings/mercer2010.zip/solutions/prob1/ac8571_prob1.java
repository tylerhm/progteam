import java.util.*;

public class ac8571_prob1 {

	
	ac8571_prob1()
	{
		Scanner input = new Scanner(System.in);
		
		int numDays = input.nextInt();
		
		for(int c = 1; c <= numDays; c++)
		{
			//System.out.println(c);
			int numT = input.nextInt();
			int total = 0;
			for(int i = 0; i < numT; i++)
			{
				int ty = input.nextInt();
				
				if(ty == 1)
				{
					int p = input.nextInt();
					int q = input.nextInt();
					
					total += p * q;
				}
				else if(ty == 2)
				{
					int p = input.nextInt();
					total += p;
				}
				else if(ty == 3)
				{
					int p = input.nextInt();
					total += p;
				}
			}
			System.out.println("Day " + c + ": $" + total + ".");
		}
	}
	
	public static void main(String[] args)
	{
		ac8571_prob1 p = new ac8571_prob1();
	}
}

