import java.util.Scanner;


public class ac8565_prob1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int runs = scan.nextInt();
		for(int i  =0 ; i < runs; i++) {
			int sum = 0;
			int days = scan.nextInt();

			for(int w  =0 ; w < days; w++) {
				if(scan.nextInt() == 1) {
					sum += scan.nextInt() * scan.nextInt();
				}
				else {
					sum += scan.nextInt();
				}
			}

			System.out.println("Day " + (i+1)  + ": $" + sum + ".");
		}
	}

}

