import java.util.Scanner;

public class ac8595_prob1 {
	public static void main(String[] args) throws Exception{
		Scanner stdin = new Scanner(System.in);
		
		int totDays = stdin.nextInt();
		for(int i = 0; i < totDays; i++){
			int trans = stdin.nextInt(); 
			int tot = 0; 
			for(int j = 0; j < trans; j++){
				int type = stdin.nextInt();
				int p;
				int q;
				//System.out.println(j + trans);
				//if(j == 0)
					//tot = 0; 
				if(type == 1){
					p = stdin.nextInt();
					q = stdin.nextInt();
					tot += p*q; 
					//System.out.println(tot);
				}
				if(type == 2){
					p = stdin.nextInt();
					tot += p;
					//System.out.println(tot);
				}
				if(type == 3){
					p = stdin.nextInt();
					tot += p; 
					//System.out.println(tot);
				}
				
			}
			
			System.out.println(); 
			System.out.print("Day " + (i+ 1) + ": $" + tot + "." );
		}
		
	}

}

