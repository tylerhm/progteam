import java.io.*;
import java.util.*;

public class ac8555_prob1 {
	public static void main(String[] args) throws IOException {
		Scanner in = new Scanner(System.in);
		int days = in.nextInt();
		for(int i = 0; i < days; i++) {
			int rev = 0;
			int trans = in.nextInt();
			for(int j = 0; j < trans; j++) {
				switch(in.nextInt()) {
				case 1 : rev+=in.nextInt()*in.nextInt();
				break;
				case 2 : rev+=in.nextInt();
				break;
				case 3 : rev+=in.nextInt();
				}
			}
			System.out.printf("Day %d: $%d.%n", i+1, rev);
		}
	}
}

