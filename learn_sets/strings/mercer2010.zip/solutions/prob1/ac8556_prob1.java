import java.util.Scanner;

public class ac8556_prob1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numDays = in.nextInt();
		for (int t = 0; t < numDays; t++) {
			int T = in.nextInt();
			int sum = 0;
			for (int i = 0; i < T; i++) {
				int type = in.nextInt();
				if (type == 1) {
					int q = in.nextInt();
					int p = in.nextInt();
					sum += q * p;
				} else if (type == 2) {
					int p = in.nextInt();
					sum += p;

				} else if (type == 3) {
					int p = in.nextInt();
					sum += p;

				}
			}
			System.out.println("Day " + (t + 1) + ": $" + sum + ".");
		}
		in.close();

	}

}

