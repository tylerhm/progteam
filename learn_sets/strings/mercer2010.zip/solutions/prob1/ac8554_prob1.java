/*
3
2
1 4 5
2 6
1
3 -7
0
 */

import java.util.*;

public class ac8554_prob1 {

	public static void main(String[] args) {
		new ac8554_prob1();
	}
	
	public ac8554_prob1() {
		Scanner sc = new Scanner(System.in);
		
		int days = sc.nextInt();
		for(int tc = 1; tc <= days; tc++){
			int n = sc.nextInt();
			
			int ans = 0;
			for(int i = 0; i < n; i++){
				int t = sc.nextInt();
				
				if(t == 1){
					ans += sc.nextInt() * sc.nextInt();
				}
				else if(t == 2){
					ans += sc.nextInt();
				}
				else{
					ans += sc.nextInt();
				}
			}
			
			System.out.println("Day " + tc + ": $" + ans + ".");
		}
		
		sc.close();
	}
}

