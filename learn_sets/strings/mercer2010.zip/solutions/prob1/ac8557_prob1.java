import java.util.Scanner;


public class ac8557_prob1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int num = in.nextInt();
		for (int i = 1; i <= num; i++) {

			int n = in.nextInt();
			int total = 0;
			for (int j = 0; j < n; j++) {
				int type = in.nextInt();
				if(type == 1){
					total += in.nextInt() *in.nextInt();
				} else if(type==2){
					total += in.nextInt();
				} else
					total+= in.nextInt();
					
			}
			System.out.println("Day " + i + ": $"  + total + ".");
			
		}

	}

}

